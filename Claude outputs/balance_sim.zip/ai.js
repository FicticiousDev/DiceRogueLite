'use strict';
// The player: a turn planner that enumerates move / attack / move plans, ranks them cheaply, then plays the best few
// forward on a deterministic copy of the fight (player actions, retaliation, the whole enemy turn) and keeps the best.
const G = require('./game');
const { CAT, hdist } = G;
const { ctxDamage, findPath } = require('./fight');
const { equipItem } = require('./run');

const TOP_K = 18;

function subsets(arr) { const out = []; const n = arr.length; for (let m = 1; m < (1 << n); m++) { const s = []; for (let i = 0; i < n; i++) if (m & (1 << i)) s.push(arr[i]); out.push(s); } return out; }

// ---------------------------------------------------------------------------------------------------------------
// Valuations
// ---------------------------------------------------------------------------------------------------------------
function faceScore(f, charId) {
  if (f.BUFF) return 2.2;
  if (f.INSTA_KILL) return 6;
  if (f.ATTACK) { let s = f.ATTACK * 1.0; if (f.CRIT) s += f.ATTACK * 0.8; if (f.STUN) s += 1.5; if (f.POISON) s += 0.8; s += (f.PENETRATE || 0) * 0.6 + (f.RANGE || 0) * (charId === 'mage' ? 0.2 : 0.8); return s; }
  if (f.DODGE) return 3.2;
  if (f.DEFENCE) return (f.DEFENCE + (charId === 'knight' ? 1 : 0)) * 0.8;
  if (f.MOVE) return f.MOVE * 0.5 + (f.TELEPORT ? 1.2 : 0);
  return 0;
}
function dieScore(die, charId) { return die.faces.reduce((s, f) => s + faceScore(f, charId), 0) / die.faces.length; }
function moveCapacity(DB, dice) { return dice.reduce((s, id) => s + DB.dice[id].faces.reduce((a, f) => a + (f.MOVE || 0), 0) / 6, 0); }
function worstIndex(DB, run, newDie) {
  let wi = -1, ws = 1e9;
  for (let i = 0; i < run.dice.length; i++) {
    const rest = run.dice.filter((_, j) => j !== i); if (newDie) rest.push(newDie.id);
    // Keep enough movement to get around
    const pen = moveCapacity(DB, rest) < 2.0 ? 3 : 0;
    const s = dieScore(DB.dice[run.dice[i]], run.character) + pen;
    if (s < ws) { ws = s; wi = i; }
  }
  return [wi, ws];
}
function itemScore(item) {
  let s = (item.max_hp || 0) * 1.5;
  for (const a of item.abilities) {
    switch (a.kind) {
      case 'extra_die_ability': s += (a.symbol === 2 ? 0.9 : 1.15) * (a.count || 1); break;
      case 'status_immunity_ability': s += (a.stun !== false ? 1.6 : 0) + (a.poison !== false ? 1.2 : 0); break;
      case 'block_attack_ability': s += 2.4; break;
      case 'ignore_terrain_ability': s += 0.9; break;
      case 'teleport_move_ability': s += 1.8; break;
      case 'heal_ability': s += 1.6; break;
      case 'cure_ability': s += (a.stun ? 1.2 : 0.7); break;
      case 'attack_modifier_ability': s += a.crit_highest ? 1.5 : 1.2; break;
    }
  }
  return s;
}
const SLOTS = [0, 1, 2, 2];

class AI {
  constructor(opts = {}) { this.opts = opts; }

  offerDie(DB, run, die) {
    if (run.dice.length < run.maxDice) { run.dice.push(die.id); return true; }
    const [wi, ws] = worstIndex(DB, run, die);
    if (dieScore(die, run.character) > ws + 0.05) { run.dice[wi] = die.id; return true; }
    return false;
  }
  offerItem(DB, run, item) {
    let best = -1, gain = 0;
    for (let i = 0; i < 4; i++) {
      if (SLOTS[i] !== item.slot) continue;
      const cur = run.equipment[i] ? itemScore(DB.equipment[run.equipment[i]]) : 0;
      if (run.equipment[i] === item.id) continue;
      const g = itemScore(item) - cur; if (g > gain) { gain = g; best = i; }
    }
    if (best >= 0) { equipItem(DB, run, item, best); return true; }
    return false;
  }
  shop(DB, run, stock) {
    let bought = true;
    while (bought) {
      bought = false; let best = null, bv = 0.3;
      for (const o of stock) {
        if (o.sold || o.price > run.gold) continue;
        let v;
        if (o.kind === 'die') v = run.dice.length < run.maxDice ? dieScore(o.v, run.character) : dieScore(o.v, run.character) - worstIndex(DB, run, o.v)[1];
        else { v = -1; for (let i = 0; i < 4; i++) if (SLOTS[i] === o.v.slot) v = Math.max(v, itemScore(o.v) - (run.equipment[i] ? itemScore(DB.equipment[run.equipment[i]]) : 0)); }
        if (v > bv) { bv = v; best = o; }
      }
      if (best) { run.gold -= best.price; best.sold = true; bought = true; best.kind === 'die' ? this.offerDie(DB, run, best.v) : this.offerItem(DB, run, best.v); }
    }
  }
  chooseNext(DB, run, map, nexts, rng) {
    if (this.opts.lookahead !== false && nexts.length > 1 && new Set(nexts.map(n => DB.levels[map[n].level].type + map[n].biome)).size > 1) return this.lookahead(DB, run, map, nexts, rng);
    let best = -1, bs = -1e9;
    for (const n of nexts) {
      const lv = DB.levels[map[n].level]; let s = rng.next();
      if (lv.type === 1 || lv.type === 2) s += run.gold >= 20 ? 3 : -0.5;
      if (lv.type === 3) s += run.health >= run.maxHealth - 1 ? 0.5 : -3;
      if (s > bs) { bs = s; best = n; }
    }
    return best;
  }
  // Tries each option a few times on copies of the run, with the level populated afresh (the gate only shows the
  // level type), and picks the best average of survival, health, dice kept and rewards.
  lookahead(DB, run, map, nexts, rng) {
    const { fightLevel, biomeStage } = require('./run');
    const trials = this.opts.trials || 6;
    let best = -1, bs = -1e9;
    const sub = new AI(Object.assign({}, this.opts, { lookahead: false }));
    for (const n of nexts) {
      const node = map[n], lv = DB.levels[node.level], biome = DB.biomes[node.biome];
      let total = 0;
      for (let t = 0; t < trials; t++) {
        const r = JSON.parse(JSON.stringify(run));
        const trng = new G.RNG(Math.floor(rng.next() * 2 ** 31));
        let v = 0;
        if (lv.type === 1 || lv.type === 2) { v = 2 + Math.min(r.gold, 60) / 10; }
        else {
          const { f, outcome } = fightLevel(DB, r, Object.assign({}, node, { seed: Math.floor(trng.next() * 2 ** 31) }), r.path.length, sub, trng, null);
          if (outcome === 'dead') v = -60;
          else {
            v = 10 * r.health / r.maxHealth - 9 * (run.dice.length - r.dice.length) + 0.15 * (r.gold - run.gold);
            if (lv.type === 3 && f.turn <= lv.turn_limit) v += 7;
            if (lv.type === 0) v += 1.5;
            if (lv.type === 4) v += 8;
          }
        }
        total += v;
      }
      const s = total / trials + rng.next() * 0.01;
      if (s > bs) { bs = s; best = n; }
    }
    return best;
  }
  sacrificeChoice(f) {
    // Never give up the last die that can attack (the pool would be stuck unable to finish a level)
    const canAttack = id => f.DB.dice[id].faces.some(x => x.ATTACK || x.INSTA_KILL);
    if (f.run.dice.filter(canAttack).length <= 1) {
      const keep = f.run.dice.findIndex(canAttack);
      const others = f.run.dice.map((_, i) => i).filter(i => i !== keep);
      if (!others.length) return -1;
      let wi = others[0], ws = 1e9; for (const i of others) { const s = dieScore(f.DB.dice[f.run.dice[i]], f.run.character); if (s < ws) { ws = s; wi = i; } }
      return wi;
    }
    const [wi] = worstIndex(f.DB, f.run, null);
    return wi;
  }
  chooseBlock(f, enemy, dmg) {
    const held = f.held().map(i => f.results[i]).sort((a, b) => a.value() - b.value());
    const blockers = f.abilities().filter(a => a.kind === 'block_attack_ability' && (f.uses[a.id] || 0) > 0);
    let pick = [];
    if (held.length) {
      const total = held.reduce((s, r) => s + r.value(), 0);
      if (total <= dmg) pick = held;
      else { const single = held.find(r => r.value() >= dmg); if (single) pick = [single]; else { for (let i = held.length - 1; i >= 0; i--) { pick.push(held[i]); if (pick.reduce((s, r) => s + r.value(), 0) >= dmg) break; } } }
    }
    const blocked = pick.reduce((s, r) => s + r.value(), 0);
    const after = Math.max(dmg - blocked, 0);
    if (blockers.length && after > 0 && (after >= f.run.health || after >= 3 || (enemy.d.is_boss && after >= 2))) {
      f.uses[blockers[0].id]--; return 999;
    }
    for (const r of pick) f.spent.add(r.idx);
    return blocked;
  }

  // -------------------------------------------------------------------------------------------------------------
  // Turn planning
  // -------------------------------------------------------------------------------------------------------------
  plan(f) {
    const pre = [];
    // Actives used as actions: heal when hurt, cure poison
    for (const a of f.abilities()) {
      if (!a.active || (f.uses[a.id] || 0) <= 0) continue;
      if (a.kind === 'heal_ability' && (f.run.health <= f.run.maxHealth - 2 || f.player.poisoned && f.run.health <= 2)) pre.push({ type: 'ability', id: a.id });
      else if (a.kind === 'cure_ability' && f.player.poisoned) pre.push({ type: 'ability', id: a.id });
    }
    const avail = f.results.filter(r => !f.spent.has(r.idx));
    const M = avail.filter(r => r.cat === CAT.MOVE).map(r => r.idx);
    const A = avail.filter(r => r.cat === CAT.ATTACK).map(r => r.idx);
    const enemies = f.board.enemies();
    const cur = f.player.tile;
    const board = f.board;
    const reachAt = (start, dice, ignored) => {
      const tele = dice.length > 0 && dice.every(i => f.results[i].face.TELEPORT) || f.has('teleport_move_ability');
      let budget = f.diceValue(dice);
      if (f.player.frozen && !tele) budget = Math.ceil(budget / 2);
      const costFn = f.has('ignore_terrain_ability') ? (id => { const c = board.cost(id); return c > 0 ? Math.min(c, 1) : c; }) : null;
      return board.reach(start, budget, f.player, ignored, costFn, tele);
    };
    const moveSets = subsets(M).slice(0, 63);
    const better = (a, b) => { const va = f.diceValue(a), vb = f.diceValue(b); return va < vb || (va === vb && a.length < b.length); };
    // Tiles reachable before attacking, with the cheapest dice that get there
    const preMoves = new Map([[cur, []]]);
    const maxRange = (f.character.attack_range || 1) + Math.max(0, ...A.map(i => f.results[i].face.RANGE || 0));
    if (A.length) for (const S of moveSets) {
      const ctx = reachAt(cur, S, null);
      for (const t of ctx.endable) {
        if (!enemies.some(e => board.inRange(t, e.tile, maxRange))) continue;
        if (!preMoves.has(t) || better(S, preMoves.get(t))) preMoves.set(t, S);
      }
    }
    // Threat: where each enemy could hit from after its move this turn (approximate: ignores pieces moving)
    const threat = new Map();
    for (const e of enemies) {
      const set = new Set();
      if (!e.d.behaviour || e.d.behaviour === 'summoner_behaviour' || e.d.behaviour === 'frost_behaviour' || e.d.behaviour === 'teleport_phase_behaviour' || e.d.behaviour === 'burst_behaviour') {
        const ctx = board.reach(e.tile, e.d.move, e, new Set([f.player]), null, false);
        const from = [e.tile, ...ctx.costs.keys()];
        for (const t of board.ids) { if (!board.walkable(t)) continue; for (const s of from) if (board.inRange(s, t, e.d.attack_range)) { set.add(t); break; } }
      } else { // charger: anything within its move along a line, roughly
        for (const t of board.ids) if (hdist(t, e.tile) <= e.d.move) set.add(t);
      }
      threat.set(e.uid, set);
    }
    const heldVals = f.held().map(i => f.results[i].value()).sort((a, b) => a - b);

    const cands = [];
    for (const [p1, S1] of preMoves) {
      const remM = M.filter(i => !S1.includes(i));
      const allocs = this.allocations(f, p1, A, enemies);
      for (const al of allocs) {
        // remaining moves after attacks; killed enemies no longer block
        const dead = new Set(al.killed.map(u => enemies.find(e => e.uid === u)));
        const finals = new Map([[p1, []]]);
        for (const S2 of subsets(remM)) { const ctx = reachAt(p1, S2, dead); for (const t of ctx.endable) if (!finals.has(t) || better(S2, finals.get(t))) finals.set(t, S2); }
        for (const [p2, S2] of finals) {
          // quick score
          let incoming = al.hits.slice();
          for (const e of enemies) {
            if (al.killed.includes(e.uid) || al.stunned.includes(e.uid) || e.stunned) continue;
            if (!threat.get(e.uid).has(p2)) continue;
            const left = Math.max(e.d.attacks_per_turn - al.retal.filter(u => u === e.uid).length, 0);
            for (let k = 0; k < left; k++) incoming.push(e.d.attack);
          }
          const taken = blockEstimate(incoming, heldVals);
          let q = al.value - hpLoss(f.run.health, taken) + (taken === 0 ? 2 : 0);
          let md = 99; for (const e of enemies) if (!al.killed.includes(e.uid)) md = Math.min(md, hdist(p2, e.tile));
          if (md === 99) { md = 0; q += 40; }
          q -= 0.25 * md;
          if (board.loot.has(p2)) q += 1;
          cands.push({ q, p1, S1, al, p2, S2 });
        }
      }
    }
    cands.sort((a, b) => b.q - a.q);
    // Deep evaluation of the best few
    let best = null, bs = -1e9;
    const seen = new Set();
    for (const c of cands) {
      if (seen.size >= TOP_K) break;
      const key = c.p1 + '|' + c.p2 + '|' + c.al.key;
      if (seen.has(key)) continue; seen.add(key);
      const plan = pre.slice();
      if (c.p1 !== cur) plan.push({ type: 'move', dice: c.S1, to: c.p1 });
      for (const at of c.al.attacks) plan.push({ type: 'attack', uid: at.uid, dice: at.dice, actives: at.actives });
      if (c.p2 !== c.p1) plan.push({ type: 'move', dice: c.S2, to: c.p2 });
      const s = this.deepScore(f, plan);
      if (s > bs) { bs = s; best = plan; }
    }
    return best || pre;
  }

  // Attack sequences from tile p: up to three targets, each with either the cheapest dice that kill it or everything left
  allocations(f, p, A, enemies) {
    const out = [{ attacks: [], killed: [], stunned: [], hits: [], retal: [], value: 0, key: '' }];
    if (!A.length) return out;
    const board = f.board;
    const actives = f.abilities().filter(a => a.active && a.use === undefined && (f.uses[a.id] || 0) > 0).map(a => a.id);
    const subs = subsets(A);
    const rec = (state, left, depth) => {
      if (depth >= 3 || !left.length) return;
      for (const e of enemies) {
        if (state.killed.includes(e.uid)) continue;
        const hp = state.hp.get(e.uid) ?? e.hp, sh = state.sh.get(e.uid) ?? e.shield;
        const options = [];
        for (const S of subs) {
          if (!S.every(i => left.includes(i))) continue;
          if (!board.inRange(p, e.tile, f.playerRange(S))) continue;
          for (const act of [[], ...actives.filter(a => (state.uses[a] || 0) > 0).map(a => [a])]) {
            const ctx = f.attackCtx(e, S, act, state.attacks.length === 0);
            const dmg = ctxDamage(ctx, e.d.defence);
            options.push({ S, act, ctx, dmg, kills: dmg >= hp + sh, cost: f.diceValue(S) + act.length * 2.5 });
          }
        }
        if (!options.length) continue;
        const picks = [];
        const killers = options.filter(o => o.kills).sort((a, b) => a.cost - b.cost);
        if (killers.length) picks.push(killers[0]);
        const allLeft = options.filter(o => o.S.length === left.filter(i => board.inRange(p, e.tile, f.playerRange([i]))).length && !o.act.length);
        if (allLeft.length) picks.push(allLeft.sort((a, b) => b.dmg - a.dmg)[0]);
        const strongest = options.slice().sort((a, b) => b.dmg - a.dmg)[0];
        if (!picks.includes(strongest)) picks.push(strongest);
        for (const o of picks) {
          const ns = applyAttack(f, state, e, o, p, enemies);
          out.push(ns);
          rec(ns, left.filter(i => !o.S.includes(i)), depth + 1);
        }
      }
    };
    rec({ attacks: [], killed: [], stunned: [], hits: [], retal: [], value: 0, key: '', hp: new Map(), sh: new Map(), uses: Object.assign({}, f.uses) }, A, 0);
    return out;
  }

  deepScore(f, plan) {
    const c = f.clone();
    const startEnemies = f.board.enemies();
    const out = c.resolvePlan(plan);
    let s = 0;
    if (out === 'dead' || c.dead()) return -10000 + c.board.enemies().length;
    if (out === 'clear') s += 60;
    s += hpValue(c.run.health) - 35 * c.sacrifices + 0.35 * c.goldGained;
    const p = c.player;
    if (p.stunned) s -= 6; if (p.poisoned) s -= 2.5; s -= 2 * p.burn; if (p.frozenNext) s -= 1.5;
    let md = 99;
    for (const e of c.board.enemies()) {
      const base = e.d.is_boss ? 45 : 8 + e.d.attack * 1.5 + (e.d.attack_range > 1 ? 2 : 0);
      const frac = (e.hp + e.shield) / (e.baseD.hp + (e.baseD.shield || 0));
      s -= base * (0.35 + 0.65 * frac);
      if (e.stunned) s += 1;
      md = Math.min(md, hdist(p.tile, e.tile));
    }
    if (md < 99) s -= 0.3 * md;
    // Unused uses of actives are worth keeping a little
    for (const k in c.uses) s += 0.8 * c.uses[k];
    return s;
  }
}

function applyAttack(f, st, e, o, p, enemies) {
  const ns = { attacks: st.attacks.concat([{ uid: e.uid, dice: o.S, actives: o.act }]), killed: st.killed.slice(), stunned: st.stunned.slice(), hits: st.hits.slice(), retal: st.retal.slice(),
    value: st.value, key: st.key + e.uid + ':' + o.S.join(',') + o.act.join(',') + ';', hp: new Map(st.hp), sh: new Map(st.sh), uses: Object.assign({}, st.uses) };
  for (const a of o.act) ns.uses[a]--;
  const first = e.d.attacks_first && !f.strikesFirst() && !e.stunned && !ns.stunned.includes(e.uid);
  if (first && f.board.inRange(e.tile, p, e.d.attack_range)) { ns.hits.push(e.d.attack); ns.retal.push(e.uid); }
  const hurt = (t, dmg) => {
    const hp = ns.hp.get(t.uid) ?? t.hp, sh = ns.sh.get(t.uid) ?? t.shield;
    const through = dmg - Math.min(sh, dmg); ns.sh.set(t.uid, sh - (dmg - through)); ns.hp.set(t.uid, Math.max(hp - through, 0));
    const maxHp = t.baseD.hp + (t.baseD.shield || 0);
    const w = t.d.is_boss ? 45 : 8 + t.d.attack * 1.5 + (t.d.attack_range > 1 ? 2 : 0);
    ns.value += w * 0.65 * Math.min(dmg, hp + sh) / maxHp;
    if (hp - through <= 0) { ns.killed.push(t.uid); ns.value += w * 0.35; }
  };
  hurt(e, o.dmg);
  for (const t of o.ctx.aoe) {
    const other = enemies.find(x => x.tile === t && x !== e && !ns.killed.includes(x.uid));
    if (other) { const sc = require('./fight').splitCtx(o.ctx, other); hurt(other, ctxDamage(sc, other.d.defence)); if (o.ctx.stun && !other.d.stun_immune && !ns.killed.includes(other.uid)) ns.stunned.push(other.uid); }
  }
  if (!ns.killed.includes(e.uid)) {
    if (o.ctx.stun && !e.d.stun_immune) ns.stunned.push(e.uid);
    else if (!first && !e.stunned && !ns.stunned.includes(e.uid) && f.board.inRange(e.tile, p, e.d.attack_range)) { ns.hits.push(e.d.attack); ns.retal.push(e.uid); }
  }
  return ns;
}
function blockEstimate(hits, held) {
  const dice = held.slice(); let taken = 0;
  for (const h of hits.sort((a, b) => b - a)) {
    let need = h;
    const single = dice.findIndex(v => v >= need);
    if (single >= 0) { dice.splice(single, 1); continue; }
    while (need > 0 && dice.length) need -= dice.pop();
    taken += Math.max(need, 0);
  }
  return taken;
}
function hpValue(h) { let s = 0; for (let i = 1; i <= h; i++) s += 3 + 9 / i; return s; }
function hpLoss(h, d) { if (d >= h) return 200; return hpValue(h) - hpValue(h - d); }

module.exports = { AI, dieScore, itemScore };
