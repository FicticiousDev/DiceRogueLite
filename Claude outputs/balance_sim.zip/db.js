'use strict';
const fs = require('fs');
function deepMerge(a, b) { for (const k in b) { if (b[k] && typeof b[k] === 'object' && !Array.isArray(b[k]) && a[k] && typeof a[k] === 'object') deepMerge(a[k], b[k]); else if (b[k] === null) delete a[k]; else a[k] = b[k]; } return a; }
const KIND = { attack_modifier_ability: [true, 0], double_attack_ability: [true, 0], block_attack_ability: [true, 1], cure_ability: [true, 2], heal_ability: [true, 2] };
function load(tunePath, extra) {
  const DB = JSON.parse(fs.readFileSync(__dirname + '/data.json'));
  if (tunePath && fs.existsSync(tunePath)) deepMerge(DB, JSON.parse(fs.readFileSync(tunePath)));
  if (extra) deepMerge(DB, extra);
  const norm = list => { for (const a of list || []) { if (KIND[a.kind]) { a.active = KIND[a.kind][0]; if (a.use === undefined) a.use = KIND[a.kind][1]; } if (a.use === 0) delete a.use; } };
  for (const c of Object.values(DB.characters)) norm(c.abilities);
  for (const e of Object.values(DB.equipment)) norm(e.abilities);
  for (const l of Object.values(DB.levels)) { l.type = l.type || 0; }
  return DB;
}
module.exports = { load, deepMerge };
