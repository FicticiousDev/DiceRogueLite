// Faithful-as-practical port of DiceBuilderRogueLite's rules (scenes/turn, scenes/run, resources/*).
'use strict';

// ---------------------------------------------------------------------------------------------------------------
// RNG
// ---------------------------------------------------------------------------------------------------------------
function mulberry32(a) {
  return function () {
    a |= 0; a = a + 0x6D2B79F5 | 0;
    let t = Math.imul(a ^ a >>> 15, 1 | a);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
class RNG {
  constructor(seed) { this.f = mulberry32(seed >>> 0); }
  next() { return this.f(); }
  int(a, b) { return a + Math.floor(this.f() * (b - a + 1)); }
  pick(arr) { return arr[Math.floor(this.f() * arr.length)]; }
  shuffle(arr) { for (let i = arr.length - 1; i > 0; i--) { const j = this.int(0, i); [arr[i], arr[j]] = [arr[j], arr[i]]; } return arr; }
}

// ---------------------------------------------------------------------------------------------------------------
// Hex
// ---------------------------------------------------------------------------------------------------------------
const NB = [[1, -1], [1, 0], [0, 1], [-1, 1], [-1, 0], [0, -1]];
const hid = (q, r) => (q + 1000) + (r + 1000) * 10000;
const hq = id => (id % 10000) - 1000;
const hr = id => Math.floor(id / 10000) - 1000;
function hdist(a, b) { const dq = hq(a) - hq(b), dr = hr(a) - hr(b); return (Math.abs(dq) + Math.abs(dr) + Math.abs(dq + dr)) / 2; }
function cubeRound(x, y, z) {
  let rq = Math.round(x), rr = Math.round(y), rs = Math.round(z);
  const dq = Math.abs(rq - x), dr = Math.abs(rr - y), ds = Math.abs(rs - z);
  if (dq > dr && dq > ds) rq = -rr - rs; else if (dr > ds) rr = -rq - rs;
  return hid(rq, rr);
}
function hline(a, b, nudge) {
  const n = hdist(a, b), res = [];
  const ax = hq(a) + nudge, ay = hr(a) + nudge, az = -hq(a) - hr(a) - 2 * nudge;
  const bx = hq(b) + nudge, by = hr(b) + nudge, bz = -hq(b) - hr(b) - 2 * nudge;
  for (let i = 0; i <= n; i++) { const t = n === 0 ? 0 : i / n; res.push(cubeRound(ax + (bx - ax) * t, ay + (by - ay) * t, az + (bz - az) * t)); }
  return res;
}
// Pointy-top, DIAMOND_DOWN: (1,-1) is a horizontal neighbour
const toXY = id => [(hq(id) - hr(id)) * 0.5, (hq(id) + hr(id)) * 0.75 * 148 / 128];

const TERRAIN_COST = [1, 2, 3, 2, -1];
const WALL = 4;
const MARK = { PLAYER: 0, ENEMY: 1, OBSTACLE: 2, EXIT: 3, LOOT: 4, SHOP: 5, BANK: 6, BOSS_POINT: 7 };
const LT = { NORMAL: 0, SHOP: 1, SHOP_BANK: 2, CHALLENGE: 3, BOSS: 4 };

// ---------------------------------------------------------------------------------------------------------------
// Board
// ---------------------------------------------------------------------------------------------------------------
class Board {
  constructor(level) {
    this.level = level;
    this.terrain = new Map();
    for (const [q, r, t] of level.tiles) this.terrain.set(hid(q, r), t);
    this.ids = [...this.terrain.keys()];
    this.nb = new Map();
    for (const id of this.ids) {
      const l = [];
      for (const [a, b] of NB) { const n = hid(hq(id) + a, hr(id) + b); if (this.terrain.has(n)) l.push(n); }
      this.nb.set(id, l);
    }
    this.markers = {};
    for (const [q, r, m] of level.markers) (this.markers[m] = this.markers[m] || []).push(hid(q, r));
    for (const k in this.markers) this.markers[k].sort((a, b) => (hq(a) - hq(b)) || (hr(a) - hr(b))); // Vector2i sort
    this.pieces = new Map();  // tile -> piece
    this.loot = new Map();    // tile -> {gold, die, item}
    this.losCache = new Map();
    this.playerStart = (this.markers[MARK.PLAYER] || [this.ids[0]])[0];
    for (const c of this.markers[MARK.OBSTACLE] || []) this.pieces.set(c, { kind: 'obstacle', blocksMove: true, blocksLos: true, occupies: true });
  }
  walkable(id) { const t = this.terrain.get(id); return t !== undefined && t !== WALL; }
  cost(id) { const t = this.terrain.get(id); return t === undefined ? -1 : TERRAIN_COST[t]; }
  piece(id) { return this.pieces.get(id) || null; }
  passable(id) { const p = this.pieces.get(id); return this.walkable(id) && (!p || !p.blocksMove); }
  blocksSight(id) { if (!this.terrain.has(id)) return false; const p = this.pieces.get(id); return this.terrain.get(id) === WALL || (p && p.blocksLos); }
  // LOS only depends on walls and obstacles (static), so cache it
  los(a, b) {
    const key = a * 100000000 + b; let v = this.losCache.get(key);
    if (v === undefined) {
      v = false;
      for (const nudge of [1e-6, -1e-6]) {
        let clear = true;
        for (const c of hline(a, b, nudge)) if (c !== a && c !== b && this.blocksSight(c)) { clear = false; break; }
        if (clear) { v = true; break; }
      }
      this.losCache.set(key, v);
    }
    return v;
  }
  inRange(a, b, range) { return hdist(a, b) <= range && this.los(a, b); }
  setPiece(p, tile) { if (p.tile !== undefined && this.pieces.get(p.tile) === p) this.pieces.delete(p.tile); p.tile = tile; this.pieces.set(tile, p); }
  remove(p) { if (this.pieces.get(p.tile) === p) this.pieces.delete(p.tile); }
  enemies() { const r = []; for (const p of this.pieces.values()) if (p.kind === 'enemy' && p.hp > 0) r.push(p); return r; }
  // Dijkstra; returns {costs, came, endable}
  reach(start, budget, mover, ignored, costFn, teleport) {
    const costs = new Map([[start, 0]]), came = new Map();
    const ign = p => p && (p === mover || (ignored && ignored.has(p)));
    if (teleport) {
      costs.clear(); const end = [];
      for (const id of this.ids) {
        const d = hdist(start, id); const p = this.pieces.get(id);
        if (d < 1 || d > budget || !this.walkable(id)) continue;
        if (p && !ign(p) && p.occupies) continue;
        if (this.los(start, id)) { costs.set(id, d); came.set(id, start); end.push(id); }
      }
      return { costs, came, endable: end, start };
    }
    const cf = costFn || (id => this.cost(id));
    const frontier = [start];
    while (frontier.length) {
      let bi = 0; for (let i = 1; i < frontier.length; i++) if (costs.get(frontier[i]) < costs.get(frontier[bi])) bi = i;
      const cur = frontier.splice(bi, 1)[0];
      for (const n of this.nb.get(cur)) {
        const step = cf(n); if (step < 0) continue;
        const p = this.pieces.get(n);
        if (!(this.walkable(n) && (!p || !p.blocksMove)) && !ign(p)) continue;
        const tot = costs.get(cur) + step;
        if (tot <= budget && (!costs.has(n) || tot < costs.get(n))) { costs.set(n, tot); came.set(n, cur); frontier.push(n); }
      }
    }
    costs.delete(start);
    const end = [];
    for (const id of costs.keys()) { const p = this.pieces.get(id); if (!p || ign(p) || !p.occupies) end.push(id); }
    return { costs, came, endable: end, start };
  }
  pathTo(ctx, id) { const path = []; if (!ctx.came.has(id)) return path; let c = id; while (c !== ctx.start) { path.unshift(c); c = ctx.came.get(c); } return path; }
  nearestFree(id) {
    const seen = new Set([id]), fr = [id];
    while (fr.length) { const c = fr.shift(); if (this.walkable(c) && !this.pieces.get(c)) return c; for (const n of this.nb.get(c) || []) if (!seen.has(n)) { seen.add(n); fr.push(n); } }
    return -1;
  }
}

// ---------------------------------------------------------------------------------------------------------------
// Dice
// ---------------------------------------------------------------------------------------------------------------
const CAT = { ATTACK: 0, DEFENCE: 1, MOVE: 2, OTHER: 3 };
function faceCat(f) {
  if (f.BUFF) return CAT.OTHER;
  if (f.ATTACK || f.CRIT || f.INSTA_KILL) return CAT.ATTACK;
  if (f.DEFENCE || f.DODGE) return CAT.DEFENCE;
  if (f.MOVE || f.TELEPORT) return CAT.MOVE;
  return CAT.OTHER;
}
function faceValue(f) { return f.ATTACK || f.DEFENCE || f.MOVE || (f.ATTACK === undefined && f.DEFENCE === undefined && f.MOVE === undefined ? (Object.values(f).find(v => typeof v === 'number') || 0) : 0); }
function faceNumeric(f) { return !f.BUFF && ((f.ATTACK || 0) > 0 || (f.DEFENCE || 0) > 0 || (f.MOVE || 0) > 0); }
class Result {
  constructor(idx, die, fi) { this.idx = idx; this.die = die; this.face = die.faces[fi]; this.bonus = 0; this.cat = faceCat(this.face); }
  applied() { if (!faceNumeric(this.face)) return 0; return Math.max(0, Math.min(this.bonus, Math.max(6 - faceValue(this.face), 0))); }
  value() { if (this.face.DODGE) return 999; return faceValue(this.face) + this.applied(); }
  canBuff() { return faceNumeric(this.face) && faceValue(this.face) + this.applied() < 6; }
}

module.exports = { RNG, NB, hid, hq, hr, hdist, hline, toXY, Board, MARK, LT, CAT, Result, faceCat, faceValue, faceNumeric, WALL };
