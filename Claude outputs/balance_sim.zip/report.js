// node report.js files... : win rate, where runs end, final dice rarity, unlock-challenge counters per run
const R = []; for (const f of process.argv.slice(2)) R.push(...require('./' + f));
const DB = require('./db').load();
const BI = ['grasslands', 'badlands', 'marsh', 'frost', 'ashlands', 'abyss'];
const chars = [...new Set(R.map(r => r.char))];
console.log('char         win%   n  | deaths by biome (boss)                         | final dice L/M | turns');
for (const ch of chars) {
  const rs = R.filter(r => r.char === ch); const w = rs.filter(r => r.won).length;
  const d = {}; for (const r of rs) if (r.died) { const k = r.died.biome.slice(0, 5) + (r.died.type === 4 ? '*' : ''); d[k] = (d[k] || 0) + 1; }
  let L = 0, M = 0; for (const r of rs) for (const id of r.final.dice) { const x = DB.dice[id]; if (x && x.rarity === 4) L++; if (x && x.rarity === 5) M++; }
  const t = rs.reduce((s, r) => s + r.turns, 0) / rs.length;
  console.log(`${ch.padEnd(12)} ${(100 * w / rs.length).toFixed(0).padStart(3)}% ${String(rs.length).padStart(3)}  | ${JSON.stringify(d).padEnd(46)} | ${(L / rs.length).toFixed(1)}/${(M / rs.length).toFixed(1)} | ${t.toFixed(0)}`);
}
const keys = ['ranged_kill', 'stun', 'poison', 'burn', 'healed', 'teleport', 'boss_defeated:tyrant', 'boss_defeated:brood_mother', 'boss_defeated:overlord'];
console.log('\nper run: ' + keys.join(', '));
for (const ch of chars) {
  const rs = R.filter(r => r.char === ch);
  console.log(ch.padEnd(12) + keys.map(k => (rs.reduce((s, r) => s + ((r.counters || {})[k] || 0), 0) / rs.length).toFixed(1)).join('  '));
}
const all = R; const flaw = all.filter(r => r.won && !((r.counters || {}).boss_damage)).length;
const clutch = all.filter(r => (r.counters || {}).clutch_boss_kill).length;
console.log(`\nwins with no boss damage: ${flaw}/${all.length} runs; clutch boss kills: ${clutch}/${all.length} runs`);
