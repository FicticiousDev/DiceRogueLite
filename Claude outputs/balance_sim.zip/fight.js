'use strict';
// One level's fight: TurnController + boss behaviours + enemy AI.
const G = require('./game');
const { hdist, hid, hq, hr, toXY, NB, CAT, MARK } = G;

let UID = 1;
const BLOCK_ALL = 999, INSTA = 999, BOSS_INSTA = 5;

function makeEnemy(data, DB) {
  const d = Object.assign({ hp: 5, move: 2, attack: 2, crit_chance: 0.05, miss_chance: 0.05, attack_range: 1, defence: 0, attacks_first: false,
    gold: 2, is_boss: false, applies_stun: false, applies_poison: false, applies_freeze: false, applies_fire: false, attacks_per_turn: 1,
    stun_immune: false, shield: 0, shield_regen: 0, segments: 0, starting_minions: 0 }, data);
  return { kind: 'enemy', uid: UID++, d, base: data.id, baseD: Object.assign({}, d), hp: d.hp, shield: d.shield, stunned: false, poisoned: false,
    master: null, home: -1, form: 0, bursts: 0, summoned: false, damaged: false, blocksMove: true, blocksLos: false, occupies: true };
}

// ---------------------------------------------------------------------------------------------------------------
class Fight {
  constructor(opts) { Object.assign(this, opts); }
  // opts: board, DB, run (shared run object), character, rng, det(bool), ai, levelType, depth
  static create(o) {
    const f = new Fight(o);
    f.player = { kind: 'player', blocksMove: true, blocksLos: false, occupies: true, stunned: false, poisoned: o.run.poisoned || false,
      frozen: false, frozenNext: false, burn: 0 };
    f.board.setPiece(f.player, f.board.playerStart);
    f.uses = f.newUses();
    f.turn = 0; f.log = [];
    return f;
  }
  clone() {
    const c = Object.create(Fight.prototype);
    Object.assign(c, this);
    const b = Object.create(G.Board.prototype); Object.assign(b, this.board);
    b.pieces = new Map(); b.loot = new Map(this.board.loot);
    const map = new Map();
    for (const [t, p] of this.board.pieces) {
      let q = p;
      if (p.kind === 'enemy') { q = Object.assign({}, p); q.d = Object.assign({}, p.d); map.set(p, q); }
      else if (p.kind === 'player') q = Object.assign({}, p);
      else if (p.kind === 'gate') q = Object.assign({}, p);
      b.pieces.set(t, q);
      if (p.kind === 'player') c.player = q;
    }
    for (const q of map.values()) if (q.master) q.master = map.get(q.master) || q.master;
    c.board = b;
    c.run = Object.assign({}, this.run); c.run.dice = this.run.dice.slice();
    c.uses = Object.assign({}, this.uses);
    c.det = true; c.log = null; c.sim = true;
    c.results = this.results; c.spent = new Set(this.spent); c.retaliated = []; c.damageTaken = this.damageTaken;
    c.sacrifices = 0; c.goldGained = 0;
    return c;
  }
  enemyByUid(uid) { for (const e of this.board.enemies()) if (e.uid === uid) return e; return null; }
  L(s) { if (this.log) this.log.push(s); }

  // ----- abilities -----
  abilities() {
    const r = [...this.character.abilities];
    for (const id of this.run.equipment) if (id) r.push(...this.DB.equipment[id].abilities);
    return r;
  }
  has(kind) { return this.abilities().some(a => a.kind === kind); }
  newUses() { const u = {}; for (const a of this.abilities()) if (a.active) u[a.id] = (u[a.id] || 0) + (a.uses_per_level || 0); return u; }
  strikesFirst() { return this.has('strike_first_ability'); }
  prevents(status) {
    return this.abilities().some(a => a.kind === 'status_immunity_ability' && ((status === 'stun' && a.stun !== false) || (status === 'poison' && a.poison !== false)));
  }
  pool() {
    const types = this.run.dice.map(id => this.DB.dice[id]);
    for (const a of this.abilities()) if (a.kind === 'extra_die_ability') {
      const sym = ['ATTACK', 'DEFENCE', 'MOVE'][a.symbol] || 'DEFENCE'; const f = {}; f[sym] = a.count;
      types.push({ id: 'extra_' + a.id, rarity: a.rarity || 0, faces: [f, f, f, f, f, f], extra: true });
    }
    return types;
  }
  playerRange(dice) {
    let bonus = -1;
    for (const i of dice) { const r = this.results[i].face.RANGE || 0; bonus = bonus === -1 ? r : Math.min(bonus, r); }
    return (this.character.attack_range || 1) + Math.max(bonus, 0);
  }
  diceValue(dice) { let t = 0; for (const i of dice) t += this.results[i].value(); return t; }

  // ----- rolling -----
  roll() {
    const types = this.pool();
    this.results = types.map((t, i) => new G.Result(i, t, Math.floor(this.rng.next() * 6)));
    this.spent = new Set();
    // buffs
    for (const b of this.results) {
      if (!b.face.BUFF) continue;
      this.spent.add(b.idx);
      const cat = { ATTACK: CAT.ATTACK, DEFENCE: CAT.DEFENCE, MOVE: CAT.MOVE }[b.face.target] ?? CAT.ATTACK;
      for (const r of this.results) if (r !== b && !r.face.BUFF && r.canBuff() && r.cat === cat) r.bonus += 1;
    }
    for (const a of this.abilities()) if (a.kind === 'defence_bonus_ability')
      for (const r of this.results) if (!this.spent.has(r.idx) && r.cat === CAT.DEFENCE && r.canBuff()) r.bonus += (a.amount || 1);
  }
  held() { return this.results.filter(r => !this.spent.has(r.idx) && r.cat === CAT.DEFENCE).map(r => r.idx); }

  // ----- attack context -----
  attackCtx(enemy, dice, used, first) {
    const ctx = { parts: [], mult: [], insta: false, instaParts: [], stun: false, poison: false, pen: 0, ignoreDef: false, aoe: [], crit: false };
    let crits = 0;
    for (const i of dice) {
      const r = this.results[i], f = r.face;
      ctx.parts.push(r.value()); ctx.mult.push(1);
      crits += f.CRIT || 0;
      if (f.INSTA_KILL) { ctx.insta = true; ctx.instaParts.push(ctx.parts.length - 1); }
      if (f.STUN) ctx.stun = true; if (f.POISON) ctx.poison = true; ctx.pen += f.PENETRATE || 0;
    }
    if (ctx.insta && enemy && enemy.d.is_boss) crits += resistInsta(ctx);
    for (let k = 0; k < crits; k++) critPart(ctx);
    for (const a of this.abilities()) {
      const use = used.includes(a.id);
      switch (a.kind) {
        case 'strike_first_ability': if (first && !ctx.insta && ctx.parts.length) critPart(ctx); break;
        case 'double_attack_ability': if (use && !ctx.insta && ctx.parts.length) ctx.mult[highest(ctx)] *= 2; break;
        case 'area_attack_ability': if ((use || !a.active) && enemy) ctx.aoe = this.board.nb.get(enemy.tile).slice(); break;
        case 'ignore_defence_ability': if (use || !a.active) ctx.ignoreDef = true; break;
        case 'attack_modifier_ability': if (use) { if (a.stun) ctx.stun = true; if (a.crit_highest && !ctx.insta && ctx.parts.length) critPart(ctx); } break;
      }
    }
    return ctx;
  }
  spendUses(wanted) { const s = []; for (const id of wanted) if ((this.uses[id] || 0) > 0) { this.uses[id]--; s.push(id); } return s; }

  // ----- damage to enemies -----
  damageEnemy(e, amount) {
    e.damaged = e.damaged || amount > 0;
    const through = amount - Math.min(e.shield, amount);
    e.shield -= amount - through; e.hp = Math.max(e.hp - through, 0);
  }
  killGold(d) { return Math.round(d.gold * (1 + 0.04 * Math.max(this.depth, 0))); }
  rewardKill(e) { const g = this.killGold(e.d); this.run.gold += g; if (this.sim) this.goldGained += g; this.run.kills = (this.run.kills || 0) + 1; }
  removeDead(e) { this.board.remove(e); }
  dismissMinions(boss) { for (const m of this.board.enemies()) if (m.master === boss) { m.hp = 0; this.board.remove(m); } }
  handleDeaths(list) {
    for (const e of list) if (e.hp <= 0 && this.board.pieces.get(e.tile) === e) { this.rewardKill(e); this.board.remove(e); this.dismissMinions(e); }
  }
  reactToDamage(before) {
    for (const [e, [hp, sh]] of before) if (e.hp > 0 && e.d.behaviour && (e.hp < hp || e.shield < sh)) this.onDamaged(e, hp);
  }

  // ----- player taking hits -----
  hurtPlayer(dmg) {
    this.damageTaken += dmg;
    if (dmg >= this.run.health && this.lastStand()) return false;
    this.run.health = Math.max(this.run.health - dmg, 0);
    return true;
  }
  lastStand() {
    if (this.run.dice.length <= 1) return false;
    const idx = this.ai.sacrificeChoice(this);
    if (idx < 0) return false;
    this.run.dice.splice(idx, 1);
    if (this.sim) this.sacrifices++;
    this.run.sacrifices = (this.run.sacrifices || 0) + 1;
    // A die sacrificed from this roll leaves the row (indices after it shift in the game too, but the turn ends soon; mark it spent)
    if (this.results && this.results[idx]) this.spent.add(idx);
    this.L(`  last stand: sacrificed ${this.DB.dice[this.run.dice[idx]] ? '' : ''}die #${idx}`);
    return true;
  }
  dead() { return this.run.health <= 0; }
  // ctx: {dmg, crit, miss, negated}
  hitPlayer(enemy, raw, roll) {
    let miss = false, crit = false;
    if (roll && !this.det) {
      const r = this.rng.next(); miss = r < enemy.d.miss_chance; if (!miss && r < enemy.d.miss_chance + enemy.d.crit_chance) crit = true;
    }
    let dmg = crit ? raw * 2 : raw;
    if (miss || dmg <= 0) return;
    // block
    const blocked = this.ai.chooseBlock(this, enemy, dmg);
    if (blocked >= BLOCK_ALL) { return; }
    dmg = Math.max(dmg - blocked, 0);
    if (dmg <= 0) return;
    if (this.hurtPlayer(dmg) && !this.dead()) {
      const p = this.player, d = enemy.d;
      if (d.applies_stun && !p.stunned && !this.prevents('stun')) p.stunned = true;
      if (d.applies_poison && !p.poisoned && !this.prevents('poison')) p.poisoned = true;
      if (d.applies_freeze && !p.frozenNext) p.frozenNext = true;
      if (d.applies_fire && Math.floor(dmg / 2) > 0) p.burn += Math.floor(dmg / 2);
    }
  }
  canHit(e, target, from) { return this.board.inRange(from === undefined ? e.tile : from, target, e.d.attack_range); }
  enemyAttack(e) { if (!this.canHit(e, this.player.tile)) return false; this.hitPlayer(e, e.d.attack, true); return true; }

  // ----- player actions -----
  heal(n) {
    if (this.player.poisoned) this.player.poisoned = false;
    else if (this.run.health < this.run.maxHealth) this.run.health = Math.min(this.run.health + n, this.run.maxHealth);
  }
  moveCtx(dice, ignored) {
    const tele = dice.length > 0 && dice.every(i => this.results[i].face.TELEPORT) || this.has('teleport_move_ability');
    let budget = this.diceValue(dice);
    let costFn = null;
    if (this.has('ignore_terrain_ability')) costFn = id => { const c = this.board.cost(id); return c > 0 ? Math.min(c, 1) : c; };
    if (this.player.frozen && !tele) budget = Math.ceil(budget / 2);
    return this.board.reach(this.player.tile, budget, this.player, ignored, costFn, tele);
  }
  movePlayer(path, tele) {
    for (const t of (tele ? [path[path.length - 1]] : path)) {
      const p = this.board.pieces.get(t);
      if (p && p !== this.player && p.blocksMove) break; // something stepped in the way (summons)
      this.board.setPiece(this.player, t);
      const loot = this.board.loot.get(t);
      if (loot) {
        this.board.loot.delete(t); this.run.gold += loot.gold;
        if (this.sim) this.goldGained += loot.gold;
        else { if (loot.die) this.ai.offerDie(this.DB, this.run, loot.die); if (loot.item) { this.ai.offerItem(this.DB, this.run, loot.item); const fresh = this.newUses(); for (const k in fresh) if (!(k in this.uses)) this.uses[k] = fresh[k]; } }
      }
    }
  }
  resolveAttack(e, dice, wanted) {
    if (!e || e.hp <= 0) return;
    if (!this.board.inRange(this.player.tile, e.tile, this.playerRange(dice))) { this.L('  attack lost: out of range'); return; }
    const first = e.d.attacks_first && !this.strikesFirst();
    if (first && !e.stunned) { if (this.enemyAttack(e)) this.retaliated.push(e); if (this.dead()) return; }
    const used = this.spendUses(wanted);
    const ctx = this.attackCtx(e, dice, used, this.attacksMade === 0);
    this.attacksMade++;
    const before = new Map([[e, [e.hp, e.shield]]]);
    const dmg = ctxDamage(ctx, e.d.defence);
    this.damageEnemy(e, dmg);
    this.L(`  attack ${e.base} for ${dmg} (${e.hp} left)`);
    const hit = [e];
    for (const t of ctx.aoe) {
      const o = this.board.pieces.get(t);
      if (o && o.kind === 'enemy' && o.hp > 0 && o !== e) {
        before.set(o, [o.hp, o.shield]);
        const sc = splitCtx(ctx, o);
        this.damageEnemy(o, ctxDamage(sc, o.d.defence)); hit.push(o);
      }
    }
    for (const t of hit) if (t.hp > 0) {
      if (ctx.stun && !t.d.stun_immune && !t.stunned) t.stunned = true;
      if (ctx.poison && !t.poisoned) t.poisoned = true;
    }
    this.handleDeaths(hit.filter(t => t.hp <= 0));
    this.reactToDamage(before);
    if (e.hp > 0 && !first && !e.stunned) { if (this.enemyAttack(e)) this.retaliated.push(e); }
  }

  // ----- turn -----
  // Returns 'dead' | 'clear' | 'continue'
  startTurn() {
    this.turn++;
    if (this.board.enemies().length === 0) return 'clear';
    const p = this.player;
    if (p.poisoned) { this.hurtPlayer(1); if (this.dead()) return 'dead'; }
    if (p.burn > 0) { const b = p.burn; p.burn = 0; this.hurtPlayer(b); if (this.dead()) return 'dead'; }
    this.damageTaken = 0;
    p.frozen = p.frozenNext; p.frozenNext = false;
    if (p.stunned) {
      const cure = this.abilities().find(a => a.kind === 'cure_ability' && a.stun && (this.uses[a.id] || 0) > 0);
      if (cure) { this.uses[cure.id]--; p.stunned = false; p.poisoned = cure.poison !== false ? false : p.poisoned; }
    }
    this.retaliated = []; this.attacksMade = 0;
    if (p.stunned) { this.results = []; this.spent = new Set(); return this.finishTurn(); }
    this.roll();
    const plan = this.ai.plan(this);
    if (this.log) this.L(` T${this.turn} hp${this.run.health} @${G.hq(this.player.tile)},${G.hr(this.player.tile)} roll[${this.results.map(r => JSON.stringify(r.face).replace(/[{}"]/g, '') + (r.bonus ? '+' + r.bonus : '')).join(' | ')}] enemies[${this.board.enemies().map(e => e.base + ':' + e.hp + '@' + G.hq(e.tile) + ',' + G.hr(e.tile)).join(' ')}] plan ${plan.map(a => a.type + (a.to ? '->' + G.hq(a.to) + ',' + G.hr(a.to) : '') + (a.dice ? '[' + a.dice + ']' : '')).join(' ')}`);
    return this.resolvePlan(plan);
  }
  resolvePlan(plan) {
    this.retaliated = []; this.attacksMade = 0;
    for (const a of plan) {
      if (this.player.stunned) break;
      if (a.type === 'move') {
        // re-path from the real position (the plan's path was computed the same way)
        const ctx = this.moveCtx(a.dice, null);
        if (!ctx.endable.includes(a.to)) { this.L('  move lost'); continue; }
        this.movePlayer(this.board.pathTo(ctx, a.to));
        for (const i of a.dice) this.spent.add(i);
      } else if (a.type === 'attack') {
        for (const i of a.dice) this.spent.add(i);
        this.resolveAttack(this.enemyByUid(a.uid), a.dice, a.actives || []);
      } else if (a.type === 'ability') {
        if ((this.uses[a.id] || 0) > 0) { this.uses[a.id]--; const ab = this.abilities().find(x => x.id === a.id);
          if (ab.kind === 'heal_ability') this.heal(ab.amount || 2);
          else if (ab.kind === 'cure_ability') { if (ab.poison !== false) this.player.poisoned = false; if (ab.stun) this.player.stunned = false; } }
      }
      if (this.dead()) return 'dead';
    }
    return this.finishTurn();
  }
  finishTurn() {
    const p = this.player;
    p.stunned = false; p.frozen = false;
    if (this.board.enemies().length === 0) {
      p.frozenNext = false; p.burn = 0;
      if (this.damageTaken === 0) this.heal(1);
      return 'clear';
    }
    // unused non-defence dice are discarded
    for (const r of this.results) if (r.cat !== CAT.DEFENCE) this.spent.add(r.idx);
    this.enemyTurn();
    if (this.dead()) return 'dead';
    if (this.damageTaken === 0) this.heal(1);
    return 'continue';
  }
  enemyTurn() {
    // poison tick
    const before = new Map(), deaths = [];
    for (const e of this.board.enemies()) if (e.poisoned) { before.set(e, [e.hp, e.shield]); this.damageEnemy(e, 1); if (e.hp <= 0) deaths.push(e); }
    this.handleDeaths(deaths); this.reactToDamage(before);
    const pt = this.player.tile;
    const order = this.board.enemies().sort((a, b) => hdist(a.tile, pt) - hdist(b.tile, pt));
    for (const e of order) {
      if (e.hp <= 0 || this.board.pieces.get(e.tile) !== e) continue;
      if (e.stunned) continue;
      this.enemyTakeTurn(e);
      if (this.dead()) return;
    }
    for (const e of this.board.enemies()) { e.stunned = false; this.endOfRound(e); e.damaged = false; }
  }
  standardTurn(e) {
    const path = findPath(this, e, this.player.tile);
    for (const t of path) this.board.setPiece(e, t);
    this.enemyStrikes(e);
  }
  enemyStrikes(e) {
    const n = Math.max(e.d.attacks_per_turn - this.retaliated.filter(x => x === e).length, 0);
    for (let i = 0; i < n; i++) { if (this.dead() || !this.canHit(e, this.player.tile)) return; this.enemyAttack(e); }
  }

  // ----- bosses -----
  setupBoss(e) {
    const b = e.d.behaviour;
    if (b === 'charge_behaviour') e.home = e.tile;
    if (b === 'frost_behaviour') this.syncRange(e);
    if (b === 'teleport_phase_behaviour') this.applyForm(e, 0);
  }
  enemyTakeTurn(e) {
    switch (e.d.behaviour) {
      case 'summoner_behaviour': {
        if (!this.board.enemies().some(m => m.master === e)) {
          const tiles = this.summonTiles(e, this.player.tile, e.d.b_count || 2);
          if (tiles.length) { for (const t of tiles) this.spawnMinion(e, t); return; }
        }
        const path = findKitePath(this, e, this.player.tile);
        for (const t of path) this.board.setPiece(e, t);
        this.enemyStrikes(e); return;
      }
      case 'charge_behaviour': { const path = this.chargePlan(e); if (path.length) this.charge(e, path); return; }
      case 'frost_behaviour': {
        this.syncRange(e);
        if (e.shield > 0) { this.standardTurn(e); return; }
        const path = findKitePath(this, e, this.player.tile);
        for (const t of path) this.board.setPiece(e, t);
        this.enemyStrikes(e); return;
      }
      case 'burst_behaviour': if (e.bursts > 0) { e.bursts--; this.flameBurst(e, e.d.b_reach || 4, e.d.b_damage || 3); return; } this.standardTurn(e); return;
      default: this.standardTurn(e);
    }
  }
  onDamaged(e, hpBefore) {
    switch (e.d.behaviour) {
      case 'burst_behaviour': e.bursts += segmentsEmptied(e.baseD, hpBefore, e.hp); break;
      case 'charge_behaviour':
        if (e.summoned || e.hp <= 0 || e.hp * 2 > e.baseD.hp) return;
        e.summoned = true; for (const t of this.sideTiles(e)) this.spawnMinion(e, t); break;
      case 'frost_behaviour': this.syncRange(e); break;
      case 'teleport_phase_behaviour':
        for (let i = 0; i < segmentsEmptied(e.baseD, hpBefore, e.hp); i++) { if (e.hp <= 0) return; this.phase(e); }
        break;
    }
  }
  endOfRound(e) {
    if (e.d.behaviour === 'frost_behaviour' && !e.damaged && e.shield < e.baseD.shield) { e.shield = Math.min(e.shield + e.d.shield_regen, e.baseD.shield); this.syncRange(e); }
  }
  syncRange(e) { e.d.attack_range = e.shield > 0 ? 1 : e.baseD.attack_range; }
  applyForm(e, i) {
    const FORMS = this.DB.overlordForms || [{ attack_range: 4, attack: 3, move: 2, defence: 1 }, { attack_range: 1, attack: 4, move: 3, defence: 2 }];
    e.form = i; Object.assign(e.d, FORMS[i]);
  }
  phase(e) {
    const pc = this.player.tile;
    const marks = (this.board.markers[MARK.BOSS_POINT] || []).slice();
    if (!marks.length) return;
    marks.sort((a, b) => (hdist(b, pc) - hdist(a, pc)) || (a - b));
    const closest = marks[marks.length - 1];
    for (const t of marks) { const p = this.board.pieces.get(t); if (!p || p === e) { if (t !== e.tile) this.board.setPiece(e, t); break; } }
    const spawn = this.board.nearestFree(closest);
    if (spawn !== -1) this.spawnMinion(e, spawn);
    this.applyForm(e, (e.form + 1) % 2);
  }
  spawnMinion(boss, tile) {
    const m = makeEnemy(this.DB.enemies[boss.d.minion], this.DB); m.master = boss; this.board.setPiece(m, tile); return m;
  }
  summonTiles(boss, target, count) {
    const free = this.board.nb.get(boss.tile).filter(t => this.board.walkable(t) && !this.board.pieces.get(t));
    free.sort((a, b) => (hdist(a, target) - hdist(b, target)) || (a - b));
    return free.slice(0, count);
  }
  chargePlan(e) {
    const [px, py] = toXY(this.player.tile), [ex, ey] = toXY(e.tile);
    const wanted = Math.atan2(py - ey, px - ex);
    const opts = NB.map(([a, b], i) => { const [sx, sy] = toXY(hid(hq(e.tile) + a, hr(e.tile) + b)); let d = Math.atan2(sy - ey, sx - ex) - wanted; d = Math.abs(Math.atan2(Math.sin(d), Math.cos(d))); return [d, i]; });
    opts.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    for (const [, i] of opts) {
      const path = []; let q = hq(e.tile), r = hr(e.tile);
      for (let s = 0; s < e.d.move; s++) {
        q += NB[i][0]; r += NB[i][1]; const t = hid(q, r);
        if (!this.board.walkable(t)) break;
        const p = this.board.pieces.get(t);
        if (p && p.blocksMove && !(p.kind === 'player' || p.kind === 'enemy')) break;
        path.push(t);
      }
      if (path.length) return path;
    }
    return [];
  }
  charge(e, path) {
    let landing = e.tile;
    for (const t of path) if (!this.board.pieces.get(t)) landing = t;
    for (const t of path) { this.hitPiece(e, t, e.d.attack); if (this.dead()) return; }
    if (landing !== e.tile && e.hp > 0) this.board.setPiece(e, landing);
  }
  flameBurst(e, reach, dmg) {
    const tiles = [];
    for (const [a, b] of NB) { let q = hq(e.tile), r = hr(e.tile); for (let s = 0; s < reach; s++) { q += a; r += b; const t = hid(q, r); if (!this.board.terrain.has(t) || this.board.blocksSight(t)) break; tiles.push(t); } }
    for (const t of tiles) { if (this.dead()) break; this.hitPiece(e, t, dmg); }
  }
  hitPiece(att, t, dmg) {
    const p = this.board.pieces.get(t);
    if (p === this.player) this.hitPlayer(att, dmg, false);
    else if (p && p.kind === 'enemy' && p !== att && p.hp > 0) { p.hp = Math.max(0, p.hp - Math.max(dmg - p.d.defence, 0)); if (p.hp <= 0) this.board.remove(p); }
  }
  sideTiles(e) {
    const home = e.home; let reach = 0;
    for (const t of this.board.ids) if (this.board.walkable(t)) reach = Math.max(reach, hdist(home, t));
    const tiles = [];
    for (let i = 0; i < 6; i++) {
      const near = Math.floor(reach / 2);
      const q = hq(home) + NB[i][0] * near + NB[(i + 1) % 6][0] * (reach - near), r = hr(home) + NB[i][1] * near + NB[(i + 1) % 6][1] * (reach - near);
      const t = this.board.nearestFree(hid(q, r));
      if (t !== -1 && !tiles.includes(t)) tiles.push(t);
    }
    return tiles;
  }
}

function segmentsEmptied(d, before, after) {
  let c = 0; for (let k = 1; k < d.segments; k++) { const bd = Math.floor(d.hp * (d.segments - k) / d.segments); if (before > bd && after <= bd) c++; } return c;
}
function highest(ctx) { let b = -1; for (let i = 0; i < ctx.parts.length; i++) if (b === -1 || ctx.parts[i] * ctx.mult[i] > ctx.parts[b] * ctx.mult[b]) b = i; return b; }
function critPart(ctx) { const h = highest(ctx); if (h >= 0) { ctx.mult[h] *= 2; ctx.crit = true; } }
function resistInsta(ctx) { ctx.insta = false; for (const i of ctx.instaParts) ctx.parts[i] = BOSS_INSTA; return ctx.instaParts.length; }
function ctxRaw(ctx) { let t = 0; for (let i = 0; i < ctx.parts.length; i++) t += ctx.parts[i] * ctx.mult[i]; return t; }
function ctxDamage(ctx, def) { if (ctx.insta) return INSTA; let t = ctxRaw(ctx); if (!ctx.ignoreDef) t -= Math.max(def - ctx.pen, 0); return Math.max(t, 0); }
function splitCtx(ctx, other) {
  const c = Object.assign({}, ctx, { parts: ctx.parts.slice(), mult: ctx.mult.slice(), instaParts: ctx.instaParts.slice() });
  if (c.insta && other.d.is_boss) { const n = resistInsta(c); for (let k = 0; k < n; k++) critPart(c); }
  return c;
}

// ---------------------------------------------------------------------------------------------------------------
// Enemy AI (EnemyAI.find_path / find_kite_path)
// ---------------------------------------------------------------------------------------------------------------
function findPath(f, e, target) {
  if (f.canHit(e, target)) return [];
  const ctx = f.board.reach(e.tile, 999, e, null, null, false);
  let best = -1;
  for (const t of ctx.endable) {
    if (!f.canHit(e, target, t)) continue;
    const c = ctx.costs.get(t);
    if (best === -1 || c < ctx.costs.get(best) || (c === ctx.costs.get(best) && t < best)) best = t;
  }
  if (best === -1) return [];
  const path = f.board.pathTo(ctx, best);
  const endable = new Set(ctx.endable);
  let steps = path.length;
  while (steps > 0 && (ctx.costs.get(path[steps - 1]) > e.d.move || !endable.has(path[steps - 1]))) steps--;
  return path.slice(0, steps);
}
function findKitePath(f, e, target) {
  const ctx = f.board.reach(e.tile, e.d.move, e, null, null, false);
  const opts = ctx.endable.slice(); opts.push(e.tile);
  let best = -1, bd = -1;
  for (const t of opts) {
    if (!f.canHit(e, target, t)) continue;
    const d = hdist(t, target), c = ctx.costs.get(t) || 0, bc = ctx.costs.get(best) || 0;
    if (best === -1 || d > bd || (d === bd && (c < bc || (c === bc && t < best)))) { best = t; bd = d; }
  }
  if (best === -1) return findPath(f, e, target);
  if (best === e.tile) return [];
  return f.board.pathTo(ctx, best);
}

module.exports = { Fight, makeEnemy, ctxDamage, ctxRaw, splitCtx, findPath, BLOCK_ALL };
