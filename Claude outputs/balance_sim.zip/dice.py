import glob, os, re
from tres import parse, refs
ROOT="/home/claude/work/DiceRogueLite"
SYM="ATTACK DEFENCE MOVE CRIT INSTA_KILL DODGE TELEPORT BUFF STUN POISON PENETRATE RANGE".split()
def load_die(path):
    ext,subs,res=parse(path)
    faces=[]
    for fid in refs(res["faces"]):
        f=subs[fid]; syms={}
        for sid in refs(f.get("symbols","")):
            s=subs[sid]; t=SYM[int(s.get("symbol","0"))]; syms[t]=syms.get(t,0)+int(s.get("count","1"))
        if "BUFF" in syms: syms["target"]=SYM[int(f.get("buff_target","0"))]
        faces.append(syms)
    return dict(id=res["id"].strip('&"'),rarity=int(res.get("rarity","0")),loot=res.get("loot","false")=="true",
                unlocked=res.get("starts_unlocked","true")=="true",faces=faces)
def all_dice():
    return {d["id"]:d for d in (load_die(p) for p in sorted(glob.glob(ROOT+"/data/dice/*.tres")))}
if __name__=="__main__":
    def fs(f):
        return "+".join(("%s%d"%(k[:3],v) if k!="target" else "->"+v[:3]) for k,v in f.items()) or "blank"
    for d in all_dice().values():
        print(f'{d["id"]:22} r{d["rarity"]} loot={d["loot"]:d} unl={d["unlocked"]:d} | '+" ".join(fs(f) for f in d["faces"]))
