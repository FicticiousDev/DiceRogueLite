// node stats.js files... : per-biome difficulty table
const R = []; for (const f of process.argv.slice(2)) R.push(...require('./' + f));
const BI = ['grasslands', 'badlands', 'marsh', 'frost', 'ashlands', 'abyss'];
for (const ch of ['knight', 'assassin', 'mage']) {
  const rs = R.filter(r => r.char === ch); if (!rs.length) continue;
  const rows = [];
  for (const b of BI) {
    const lv = rs.flatMap(r => (r.lv || []).filter(l => l.b === b));
    const runsIn = rs.filter(r => r.biomes.includes(b)).length;
    if (!runsIn) { rows.push(`${b.slice(0, 5)}: -`); continue; }
    const deaths = lv.filter(l => l.out === 'dead').length;
    const dmg = lv.reduce((s, l) => s + Math.max(0, l.hp0 - l.hp1), 0) / runsIn;
    const sac = lv.reduce((s, l) => s + l.sac, 0) / runsIn;
    const boss = lv.filter(l => l.t === 4);
    const bt = boss.length ? (boss.reduce((s, l) => s + l.turns, 0) / boss.length).toFixed(1) : '-';
    const bd = boss.filter(l => l.out === 'dead').length;
    rows.push(`${b.slice(0, 5)}: n${runsIn} die${(100 * deaths / runsIn).toFixed(0)}% sac${sac.toFixed(1)} boss[t${bt} d${bd}]`);
  }
  console.log(ch.padEnd(9) + ' win ' + rs.filter(r => r.won).length + '/' + rs.length + ' | ' + rows.join(' | '));
}
