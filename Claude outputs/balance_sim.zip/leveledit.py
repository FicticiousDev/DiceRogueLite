import base64, struct, re
from levels import ROOT, decode
def encode(cells):
    out=bytearray(struct.pack("<H",0))
    for (x,y),ax in sorted(cells.items()):
        out+=struct.pack("<hhHHHH",x,y,0,ax,0,0)
    return base64.b64encode(bytes(out)).decode()
def edit(name, layout_changes=None, marker_changes=None):
    """layout_changes: {(q,r): terrain or None(remove)}; marker_changes: {(q,r): marker or None}"""
    path=f"{ROOT}/scenes/levels/{name}.tscn"; t=open(path).read()
    arr=re.findall(r'tile_map_data = PackedByteArray\("([^"]*)"\)',t)
    lay=decode(arr[0]); mk=decode(arr[1])
    for c,v in (layout_changes or {}).items():
        if v is None: lay.pop(c,None)
        else: lay[c]=v
    for c,v in (marker_changes or {}).items():
        if v is None: mk.pop(c,None)
        else: mk[c]=v
    t=t.replace(arr[0],encode(lay),1).replace(arr[1],encode(mk),1)
    open(path,"w").write(t)
