import base64, struct, re, glob, os
ROOT="/home/claude/work/DiceRogueLite"
TER="NDXWB"  # normal difficult extreme water wall(#)
MARK=["P","E","O","X","L","S","K","B"]  # player, enemy, obstacle, exit, loot, shop, bank, boss_point
NB=[(1,-1),(1,0),(0,1),(-1,1),(-1,0),(0,-1)]
def decode(b64):
    d=base64.b64decode(b64); out={}
    for i in range(2,len(d),12):
        x,y,src,ax,ay,alt=struct.unpack("<hhHHHH",d[i:i+12]); out[(x,y)]=ax
    return out
def load(name):
    t=open(f"{ROOT}/scenes/levels/{name}.tscn").read()
    arr=re.findall(r'tile_map_data = PackedByteArray\("([^"]*)"\)',t)
    lay=decode(arr[0]); mk=decode(arr[1]) if len(arr)>1 else {}
    return lay,mk
def dist(a,b):
    dx,dy=a[0]-b[0],a[1]-b[1]; return (abs(dx)+abs(dy)+abs(dx+dy))//2
def render(lay,mk):
    xs=[q-r for q,r in lay]; ys=[q+r for q,r in lay]
    out=[]
    for y in range(min(ys),max(ys)+1):
        row=[" "]*(max(xs)-min(xs)+2)
        for (q,r),t in lay.items():
            if q+r!=y: continue
            ch=".dx~#"[t]
            if (q,r) in mk: ch=MARK[mk[(q,r)]]
            row[q-r-min(xs)]=ch
        out.append("".join(row))
    return "\n".join(out)
def render_old(lay,mk):
    # axial q=x,r=y; draw rows by r, offset by q
    rs=[c[1] for c in lay]; qs=[c[0] for c in lay]
    lines=[]
    for r in range(min(rs),max(rs)+1):
        pass
    # use pixel coords: diamond down layout -> x = q - r? approximate: col = 2*q + r ... print grid by (q, r)
    out=[]
    for r in range(min(rs)-0,max(rs)+1):
        line=" "*(r-min(rs))
        for q in range(min(qs),max(qs)+1):
            c=(q,r)
            if c in lay:
                ch=".dx~#"[lay[c]]
                if c in mk: ch=MARK[mk[c]]
                line+=ch+" "
            else: line+="  "
        out.append(line)
    return "\n".join(out)
if __name__=="__main__":
    import sys
    for n in sys.argv[1:]:
        lay,mk=load(n); print(n, len(lay)); print(render(lay,mk)); print()
