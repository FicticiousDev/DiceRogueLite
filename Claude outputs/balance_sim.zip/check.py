from levels import *
import glob,os
names=sorted(os.path.basename(p)[:-5] for p in glob.glob(ROOT+"/scenes/levels/*.tscn"))
def nbrs(c): return [(c[0]+a,c[1]+b) for a,b in NB]
for n in names:
    lay,mk=load(n)
    blocked={c for c,m in mk.items() if m in (2,3,5,6)}  # obstacles, exits(gated worst case), shop, bank
    walk={c for c,t in lay.items() if t!=4 and c not in blocked}
    start=[c for c,m in mk.items() if m==0]
    if not start: print(n,"NO START"); continue
    s=start[0]; seen={s}; fr=[s]
    while fr:
        c=fr.pop()
        for d in nbrs(c):
            if d in walk and d not in seen: seen.add(d); fr.append(d)
    bad=[]
    for c,m in mk.items():
        if m in (1,4,7):
            # reachable tile adjacent (or itself)
            if c not in seen and not any(d in seen for d in nbrs(c)):
                bad.append((MARK[m],c))
            elif m==1 and c not in seen:
                bad.append(("E-adj-only",c))
    unreach=[c for c in walk if c not in seen]
    if bad or unreach: print(n, "bad:",bad, "unreachable walkable:",unreach)
