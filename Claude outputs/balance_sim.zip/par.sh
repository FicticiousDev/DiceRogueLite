#!/bin/bash
# usage: par.sh N SEED OUTPREFIX [extra args]
N=$1; SEED=$2; OUT=$3; shift 3
node main.js --n $N --seed $SEED --chars knight,mage --quiet 1 --out ${OUT}_a.json "$@" > ${OUT}_a.txt &
node main.js --n $N --seed $SEED --chars assassin --quiet 1 --out ${OUT}_b.json "$@" > ${OUT}_b.txt &
wait
cat ${OUT}_a.txt ${OUT}_b.txt
node -e "
const R=[...require('./${OUT}_a.json'),...require('./${OUT}_b.json')];
const BI=['grasslands','badlands','marsh','frost','ashlands','abyss'];
for (const ch of ['knight','assassin','mage']) { const rs=R.filter(r=>r.char===ch); if(!rs.length) continue;
  const reach={}; for(const r of rs) for(const b of r.biomes) reach[b]=(reach[b]||0)+1;
  const bossD={}; for(const r of rs) if(r.died&&r.died.type===4) bossD[r.died.biome]=(bossD[r.died.biome]||0)+1;
  const chD=rs.filter(r=>r.died&&r.died.type===3).length;
  console.log(ch.padEnd(9),'reach',BI.map(b=>b.slice(0,4)+':'+(reach[b]||0)).join(' '),'| bossDeaths',JSON.stringify(bossD),'challengeDeaths',chD,'| avgSacr',(rs.reduce((s,r)=>s+r.final.sacrifices,0)/rs.length).toFixed(1),'avgTurns',(rs.reduce((s,r)=>s+r.turns,0)/rs.length).toFixed(0), 'stalls', rs.filter(r=>r.stalled).length);
}"
