import json, glob, os, re
from levels import load, ROOT
from dice import all_dice
from tres import parse, refs
def val(v):
    v=v.strip()
    if v in("true","false"): return v=="true"
    if v.startswith('&"') or v.startswith('"'): return v.strip('&"')
    try: return int(v)
    except: pass
    try: return float(v)
    except: return v
def enemies():
    out={}
    for p in glob.glob(ROOT+"/data/enemies/*.tres"):
        ext,subs,res=parse(p)
        d={k:val(v) for k,v in res.items() if k not in("script","tint","texture","behaviour","minion","description")}
        if "behaviour" in res:
            sid=refs(res["behaviour"])[0]; b=subs[sid]
            script=[e for i,e in ext.items() if i==re.search(r'ExtResource\("([^"]+)"\)',b["script"]).group(1)][0]
            d["behaviour"]=os.path.basename(script)[:-3]
            for k,v in b.items():
                if k!="script": d["b_"+k]=val(v)
        if "minion" in res:
            i=re.search(r'ExtResource\("([^"]+)"\)',res["minion"]).group(1); d["minion"]=os.path.basename(ext[i])[:-5]
        out[d["id"]]=d
    return out
def simple(dirname):
    out={}
    for p in glob.glob(ROOT+f"/data/{dirname}/*.tres"):
        ext,subs,res=parse(p)
        d={k:val(v) for k,v in res.items() if k not in("script","terrain_colors","color","tint","texture","scene","icon")}
        if "enemy_ids" in res: d["enemy_ids"]=re.findall(r'&"(\w+)"',res["enemy_ids"])
        if "enemy_count" in res: d["enemy_count"]=[int(x) for x in re.findall(r'-?\d+',res["enemy_count"])]
        if "starting_dice" in res: d["starting_dice"]=re.findall(r'&"(\w+)"',res["starting_dice"])
        if "abilities" in res:
            ab=[]
            for sid in refs(res["abilities"]):
                s=subs[sid]; sc=os.path.basename(ext[re.search(r'ExtResource\("([^"]+)"\)',s["script"]).group(1)])[:-3]
                a={k:(re.findall(r'&"(\w+)"',v) if k=="boosts" else val(v)) for k,v in s.items() if k not in("script","description","display_name")}; a["kind"]=sc; ab.append(a)
            d["abilities"]=ab
        out[d["id"]]=d
    return out
levels={}
for p in glob.glob(ROOT+"/data/levels/*.tres"):
    ext,subs,res=parse(p); d={k:val(v) for k,v in res.items() if k not in("script","scene")}
    d.setdefault("type",0); d.setdefault("stage",0); d.setdefault("exit_count",3); d.setdefault("turn_limit",0)
    if not os.path.exists(ROOT+"/scenes/levels/"+d["id"]+".tscn"): continue
    lay,mk=load(d["id"]); d["tiles"]=[[c[0],c[1],t] for c,t in lay.items()]; d["markers"]=[[c[0],c[1],m] for c,m in mk.items()]
    levels[d["id"]]=d
data=dict(dice=all_dice(),enemies=enemies(),biomes=simple("biomes"),characters=simple("characters"),equipment=simple("equipment"),levels=levels)
json.dump(data,open("data.json","w"),indent=0)
print({k:len(v) for k,v in data.items()})
print(json.dumps(data["characters"]["mage"]),json.dumps(data["enemies"]["tyrant"]),json.dumps(data["equipment"]["chain_armour"]))
