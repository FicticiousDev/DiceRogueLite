import re
def parse(path):
    txt=open(path).read()
    ext={}; subs={}; res=None; cur=None
    for block in re.split(r'\n(?=\[)', txt):
        head=block.split("\n",1)[0]
        body=block.split("\n",1)[1] if "\n" in block else ""
        props={}
        # properties may span lines; simple: key = value per line
        for line in body.split("\n"):
            m=re.match(r'^([\w/]+) = (.*)$',line)
            if m: props[m.group(1)]=m.group(2)
        if head.startswith("[ext_resource"):
            i=re.search(r'id="([^"]+)"',head).group(1); p=re.search(r'path="([^"]+)"',head).group(1); ext[i]=p
        elif head.startswith("[sub_resource"):
            i=re.search(r'id="([^"]+)"',head).group(1); subs[i]=props
        elif head.startswith("[resource]"):
            res=props
    return ext,subs,res
def refs(v): return re.findall(r'SubResource\("([^"]+)"\)',v)
