// node leveleval.js snaps.json [trials] [filter] : per level x biome x character outcome table from biome-entry snapshots
const { load } = require('./db'); const { fightLevel } = require('./run'); const { AI } = require('./ai'); const G = require('./game');
const args = process.argv.slice(2);
const DB = load(__dirname + '/tune.json');
const runs = require('./' + args[0]); const trials = +(args[1] || 20); const filt = args[2] || '';
const ai = new AI({ lookahead: false });
const snaps = {}; for (const r of runs) for (const b in (r.snaps || {})) (snaps[r.char + ':' + b] = snaps[r.char + ':' + b] || []).push(r.snaps[b]);
const stageOf = b => Math.floor(DB.biomes[b].order / 2) + 1;
const rng = new G.RNG(99);
const out = [];
for (const b of Object.keys(DB.biomes).sort((x, y) => DB.biomes[x].order - DB.biomes[y].order)) {
  const levels = Object.values(DB.levels).filter(l => (l.type === 0 || l.type === 3) && l.stage === stageOf(b) || l.id === DB.biomes[b].boss_level);
  for (const l of levels) {
    if (filt && !l.id.includes(filt) && !b.includes(filt)) continue;
    const row = [b.slice(0, 5), l.id.padEnd(16)];
    for (const ch of ['knight', 'assassin', 'mage']) {
      const pool = snaps[ch + ':' + b]; if (!pool || !pool.length) { row.push('      -       '); continue; }
      let dead = 0, hp = 0, sac = 0, turns = 0;
      for (let t = 0; t < trials; t++) {
        const run = JSON.parse(JSON.stringify(pool[t % pool.length]));
        const h0 = run.health, d0 = run.dice.length;
        const node = { level: l.id, biome: b, next: [1, 2], seed: Math.floor(rng.next() * 2 ** 31) };
        const { f, outcome } = fightLevel(DB, run, node, 3 * stageOf(b), ai, new G.RNG(Math.floor(rng.next() * 2 ** 31)), null);
        if (outcome === 'dead') dead++; hp += h0 - run.health; sac += d0 - run.dice.length; turns += f.turn;
      }
      row.push(`d${String(Math.round(100 * dead / trials)).padStart(3)}% hp${(hp / trials).toFixed(1).padStart(4)} s${(sac / trials).toFixed(1)} t${(turns / trials).toFixed(1).padStart(4)}`);
    }
    console.log(row.join(' | '));
  }
}
