# Balance simulator
- `python3 export.py` reads the project (set ROOT in levels.py/dice.py) into data.json.
- `python3 check.py` flags enemy/loot/boss points the player can't walk to (worst case: every exit gated).
- `node main.js --n 20` plays 20 runs per character; `--tune file.json` overlays stat changes; `--route frost` forces a biome.
- `node leveleval.js snaps.json 30` scores every level per character from biome-entry snapshots (`main.js --snap 1 --out x.json`).
