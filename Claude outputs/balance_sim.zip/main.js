'use strict';
const { load } = require('./db');
const { playRun } = require('./run');
const { AI } = require('./ai');
const args = process.argv.slice(2);
const opt = k => { const i = args.indexOf('--' + k); return i >= 0 ? args[i + 1] : null; };
const DB = load(opt('tune') || __dirname + '/tune.json');
if (opt('unlocked')) DB.allUnlocked = true;
const chars = (opt('chars') || 'knight,assassin,mage,monk,acrobat,pyro,void_dancer,tank,sniper').split(',');
if (opt('oldrarity')) DB.oldRarity = true;
if (opt('noknock')) DB.noKnockback = true;
const n = +(opt('n') || 20), base = +(opt('seed') || 1000);
const verbose = !!opt('verbose');
const ai = new AI();
const results = [];
for (const ch of chars) for (let i = 0; i < n; i++) {
  const t0 = Date.now();
  const r = playRun(DB, ch, base + i * 7919, ai, { verbose, snap: !!opt('snap'), route: opt('route') ? opt('route').split(',') : null });
  r.ms = Date.now() - t0; results.push(r);
  if (verbose) console.log(r.log.join('\n'));
  if (!opt('quiet')) console.log(`${ch} #${i} ${r.won ? 'WON' : 'died ' + r.died.biome + ' ' + r.died.level + ' d' + r.died.depth} levels=${r.levels} turns=${r.turns} ${r.ms}ms ${r.stalled ? 'STALLED' : ''}`);
}
if (opt('out')) require('fs').writeFileSync(opt('out'), JSON.stringify(results));
const BI = ['grasslands', 'badlands', 'marsh', 'frost', 'ashlands', 'abyss'];
for (const ch of chars) {
  const rs = results.filter(r => r.char === ch);
  const wins = rs.filter(r => r.won).length;
  const deaths = {}; for (const r of rs) if (r.died) { const k = r.died.biome + (r.died.type === 4 ? '(boss)' : ''); deaths[k] = (deaths[k] || 0) + 1; }
  const avgL = rs.reduce((s, r) => s + r.levels, 0) / rs.length;
  console.log(`${ch.padEnd(9)} wins ${wins}/${rs.length}  avg levels ${avgL.toFixed(1)}  deaths ${JSON.stringify(deaths)}`);
}
