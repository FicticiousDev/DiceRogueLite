'use strict';
// Run flow: RunMap.generate, Run._populate, awards, shops, boss bonus.
const G = require('./game');
const { Fight, makeEnemy } = require('./fight');
const { MARK, LT, hdist } = G;

const DICE_TIER_ODDS = [0.65, 0.28, 0.07];
const SHOP_TIER_ODDS = [0.55, 0.365, 0.085];
const PRICES = [10, 20, 35, 55, 80, 120];

function rollStep(rng, odds) { let r = rng.next(), s = 0; while (s < odds.length - 1 && r >= odds[s]) { r -= odds[s]; s++; } return s; }
function lootDice(DB, tier) { return Object.values(DB.dice).filter(d => d.loot && d.rarity === tier && (d.unlocked || DB.allUnlocked)).sort((a, b) => a.id < b.id ? -1 : 1); }
function availDice(DB, tier) { const c = []; for (let t = tier; t <= 5; t++) c.push(t); for (let t = tier - 1; t >= 0; t--) c.push(t); for (const t of c) { const d = lootDice(DB, t); if (d.length) return d; } return []; }
function rollDie(DB, rng, difficulty, top) { const tier = Math.max(0, Math.min(difficulty - 1, 5)); const step = top ? 2 : rollStep(rng, DICE_TIER_ODDS); const d = availDice(DB, Math.min(tier + step, 5)); return d.length ? d[Math.floor(rng.next() * d.length)] : null; }
function itemsOf(DB, tier) { return Object.values(DB.equipment).filter(i => i.loot !== false && i.rarity === tier && (i.starts_unlocked !== false || DB.allUnlocked)); }
function availItems(DB, tier) { const c = []; for (let t = tier; t <= 5; t++) c.push(t); for (let t = tier - 1; t >= 0; t--) c.push(t); for (const t of c) { const i = itemsOf(DB, t); if (i.length) return i; } return []; }
function rollItem(DB, rng, difficulty, atLeast) {
  const base = Math.max(0, Math.min(difficulty - 1, 5)); const w = []; let tot = 0;
  for (let t = 0; t < 6; t++) { const x = atLeast && t < base ? 0 : Math.pow(0.4, Math.abs(t - base)); w.push(x); tot += x; }
  let r = rng.next() * tot, t = 0; while (t < 5 && r >= w[t]) { r -= w[t]; t++; }
  const items = availItems(DB, t); return items.length ? items[Math.floor(rng.next() * items.length)] : null;
}
function shopStock(DB, rng, visited) {
  const base = Math.max(0, Math.min(visited - 1, 5));
  const tiers = [Math.min(base + 1, 5)]; for (let i = 0; i < 2; i++) tiers.push(Math.min(base + rollStep(rng, SHOP_TIER_ODDS), 5));
  const offers = [];
  for (const tier of tiers) {
    const itemFirst = rng.next() < 0.5; const ts = []; for (let t = tier; t <= 5; t++) ts.push(t); for (let t = tier - 1; t >= 0; t--) ts.push(t);
    let got = null;
    outer: for (const t of ts) for (const items of [itemFirst, !itemFirst]) {
      const ch = (items ? itemsOf(DB, t).map(x => ({ kind: 'item', v: x })) : lootDice(DB, t).map(x => ({ kind: 'die', v: x }))).filter(o => !offers.some(p => p.v === o.v));
      if (ch.length) { got = ch[Math.floor(rng.next() * ch.length)]; break outer; }
    }
    if (got) offers.push(got);
  }
  return offers;
}

// ---------------------------------------------------------------------------------------------------------------
// Map
// ---------------------------------------------------------------------------------------------------------------
function biomeStage(b) { return Math.floor(b.order / 2) + 1; }
function generateMap(DB, rng) {
  const nodes = [], entries = {}, bosses = {};
  const biomes = Object.values(DB.biomes).sort((a, b) => a.order - b.order);
  const LINKS = { 1: [2, 3], 2: [4, 5], 3: [4, 5], 4: [6], 5: [6], 6: [] };
  for (const b of biomes) {
    const depth = rng.int(4, 7); const layers = [], middle = [];
    for (let i = 0; i < depth; i++) {
      const width = (i === 0 || i === depth - 1) ? 1 : rng.int(2, 3); const layer = [];
      for (let j = 0; j < width; j++) {
        layer.push(nodes.length);
        nodes.push({ type: i === depth - 1 ? LT.BOSS : LT.NORMAL, biome: b.id, next: [], seed: Math.floor(rng.next() * 2 ** 31) });
        if (i > 0 && i < depth - 1) middle.push(layer[layer.length - 1]);
      }
      layers.push(layer);
    }
    for (let i = 0; i < depth - 1; i++) connect(rng, nodes, layers[i], layers[i + 1]);
    rng.shuffle(middle);
    const sole = idx => nodes.some(n => n.next.length === 1 && n.next[0] === idx);
    const spot = middle.findIndex(i => !sole(i));
    if (spot > 0) [middle[0], middle[spot]] = [middle[spot], middle[0]];
    nodes[middle[0]].type = LT.CHALLENGE;
    ensureAlt(nodes, layers, middle[0]);
    if (rng.next() < 0.6) nodes[middle[1]].type = rng.next() < 0.25 ? LT.SHOP_BANK : LT.SHOP;
    entries[b.order] = layers[0][0]; bosses[b.order] = layers[depth - 1][0];
  }
  for (const o in bosses) for (const n of LINKS[o]) nodes[bosses[o]].next.push(entries[n]);
  // choose levels
  const unused = {};
  for (const node of nodes) {
    const b = DB.biomes[node.biome];
    if (node.type === LT.BOSS && b.boss_level) { node.level = b.boss_level; continue; }
    const stage = (node.type === LT.SHOP || node.type === LT.SHOP_BANK) ? 0 : biomeStage(b);
    const key = node.type + ':' + stage;
    const fits = l => l.exit_count >= node.next.length;
    let cand = (unused[key] || []).filter(fits);
    if (!cand.length) { unused[key] = Object.values(DB.levels).filter(l => l.type === node.type && (stage === 0 || l.stage === stage)); cand = unused[key].filter(fits); }
    const pick = cand[Math.floor(rng.next() * cand.length)];
    if (!pick) throw new Error('no level for ' + key + ' exits ' + node.next.length);
    unused[key].splice(unused[key].indexOf(pick), 1);
    node.level = pick.id;
  }
  return nodes;
}
function connect(rng, nodes, from, to) {
  const maxOut = from.length === 1 ? 3 : 2; let edges = [];
  while (!edges.length) {
    let i = 0, j = 0; edges = [[0, 0]];
    while (i < from.length - 1 || j < to.length - 1) {
      let step = rng.int(0, 2);
      if (i === from.length - 1) step = 1; else if (j === to.length - 1) step = 0;
      if (step !== 1) i++; if (step !== 0) j++; edges.push([i, j]);
    }
    for (let k = 0; k < from.length; k++) if (edges.filter(e => e[0] === k).length > maxOut) edges = [];
  }
  for (const [a, b] of edges) nodes[from[a]].next.push(to[b]);
}
function ensureAlt(nodes, layers, ch) {
  const at = layers.findIndex(l => l.includes(ch)); const layer = layers[at], before = layers[at - 1]; const j = layer.indexOf(ch);
  const reach = (n, low) => { const p = nodes[n].next.map(x => layer.indexOf(x)).filter(x => x !== -1); return low ? Math.min(...p) : Math.max(...p); };
  for (let k = 0; k < before.length; k++) {
    const node = nodes[before[k]]; if (node.next.length !== 1 || node.next[0] !== ch) continue;
    const opts = [];
    if (j + 1 < layer.length && before.slice(k + 1).every(p => reach(p, true) > j)) opts.push(layer[j + 1]);
    if (j > 0 && before.slice(0, k).every(p => reach(p, false) < j)) opts.push(layer[j - 1]);
    if (!opts.length) opts.push(j + 1 < layer.length ? layer[j + 1] : layer[j - 1]);
    node.next.push(opts[0]);
  }
}

// ---------------------------------------------------------------------------------------------------------------
// Run
// ---------------------------------------------------------------------------------------------------------------
function populate(DB, board, node, level, depth, rng) {
  const biome = DB.biomes[node.biome];
  const lrng = new G.RNG(node.seed);
  const shuffled = cells => { cells = cells.slice().sort((a, b) => (G.hq(a) - G.hq(b)) || (G.hr(a) - G.hr(b))); return lrng.shuffle(cells); };
  let enemyCells = shuffled(board.markers[MARK.ENEMY] || []);
  let count = lrng.int(biome.enemy_count[0], biome.enemy_count[1]);
  const spawned = [];
  if (level.type === LT.BOSS) {
    const cells = enemyCells.slice().sort((a, b) => hdist(b, board.playerStart) - hdist(a, board.playerStart));
    const data = DB.enemies[biome.boss_id];
    const boss = makeEnemy(data, DB); board.setPiece(boss, cells.shift()); spawned.push(boss);
    for (const c of cells.slice(0, data.starting_minions || 0)) { const m = makeEnemy(DB.enemies[data.minion], DB); m.master = boss; board.setPiece(m, c); spawned.push(m); }
    enemyCells = [];
  }
  if (level.type === LT.CHALLENGE) count = enemyCells.length;
  const ids = biome.enemy_ids;
  for (const c of enemyCells.slice(0, count)) { const e = makeEnemy(DB.enemies[ids[Math.floor(lrng.next() * ids.length)]], DB); board.setPiece(e, c); spawned.push(e); }
  const loot = shuffled(board.markers[MARK.LOOT] || []);
  const n = Math.min(Math.max(Math.round(loot.length * (0.2 + 0.04 * depth)), loot.length > 0 ? 1 : 0), loot.length);
  for (const c of loot.slice(0, n)) {
    const roll = rng.next();
    const die = roll < 0.15 ? rollDie(DB, rng, biome.difficulty) : null;
    const item = !die && roll < 0.25 ? rollItem(DB, rng, biome.difficulty) : null;
    board.loot.set(c, { gold: lrng.int(2, 4) + biome.difficulty, die, item });
  }
  // gates on as many exit points as there are links (they block until the level is clear)
  const exits = shuffled(board.markers[MARK.EXIT] || []).slice(0, node.next.length);
  for (const c of exits) board.setPiece({ kind: 'gate', blocksMove: true, blocksLos: false, occupies: true }, c);
  for (const c of board.markers[MARK.SHOP] || []) board.setPiece({ kind: 'building', blocksMove: true, blocksLos: false, occupies: true }, c);
  for (const c of board.markers[MARK.BANK] || []) board.setPiece({ kind: 'building', blocksMove: true, blocksLos: false, occupies: true }, c);
  return spawned;
}

function newRun(DB, charId, rng) {
  const ch = DB.characters[charId];
  return { character: charId, dice: ch.starting_dice.slice(), maxDice: 5, maxHealth: ch.max_hp || 5, health: ch.max_hp || 5, gold: 0,
    equipment: ['', '', '', ''], path: [0], kills: 0, sacrifices: 0, poisoned: false };
}

function equipItem(DB, run, item, slot) {
  const old = run.equipment[slot] ? DB.equipment[run.equipment[slot]] : null;
  if (old) run.maxHealth -= old.max_hp || 0;
  run.equipment[slot] = item.id; run.maxHealth += item.max_hp || 0;
  run.health = Math.max(1, Math.min(run.health + Math.max(item.max_hp || 0, 0), run.maxHealth));
}

// One level's fight on [run] (changed in place). Returns the fight and 'dead' | 'clear'.
function fightLevel(DB, run, node, depth, ai, rng, log) {
  const level = DB.levels[node.level]; const biome = DB.biomes[node.biome];
  const board = new G.Board(level);
  populate(DB, board, node, level, depth, rng);
  const f = Fight.create({ board, DB, run, character: DB.characters[run.character], rng, det: false, ai, levelType: level.type, depth, biome });
  for (const e of board.enemies()) if (e.d.behaviour) f.setupBoss(e);
  if (log) f.log = log;
  let outcome = 'continue';
  while (outcome === 'continue') { outcome = f.startTurn(); if (f.turn > 200) outcome = 'dead'; }
  run.poisoned = f.player.poisoned;
  return { f, outcome };
}

// Plays a whole run. Returns a result record.
function playRun(DB, charId, seed, ai, opts = {}) {
  const rng = new G.RNG(seed);
  const map = generateMap(DB, rng);
  const run = newRun(DB, charId, rng);
  const character = DB.characters[charId];
  const rec = { char: charId, seed, levels: 0, died: null, won: false, biomes: [], turns: 0, bossTurns: {}, log: [] };
  let index = 0;
  while (true) {
    const node = map[index]; const level = DB.levels[node.level]; const biome = DB.biomes[node.biome];
    if (!rec.biomes.includes(node.biome)) { rec.biomes.push(node.biome); if (opts.snap) (rec.snaps = rec.snaps || {})[node.biome] = JSON.parse(JSON.stringify(run)); }
    const depth = run.path.length - 1;
    const startHp = run.health;
    const { f, outcome: out0 } = fightLevel(DB, run, node, depth, ai, rng, opts.verbose ? rec.log : null);
    let outcome = out0; if (f.turn > 200) rec.stalled = true;
    rec.turns += f.turn;
    (rec.lv = rec.lv || []).push({ b: node.biome, t: level.type, id: level.id, hp0: startHp, hp1: run.health, max: run.maxHealth, sac: (run.sacrifices || 0) - (rec._sac || 0), turns: f.turn, out: outcome, dice: run.dice.length });
    rec._sac = run.sacrifices || 0;
    run.poisoned = f.player.poisoned;
    if (opts.verbose) rec.log.push(`${node.biome} ${level.id} [${['N', 'S', 'SB', 'C', 'B'][level.type]}] turns=${f.turn} hp ${startHp}->${run.health}/${run.maxHealth} dice=${run.dice.length} gold=${run.gold} ${outcome}`);
    if (outcome === 'dead') { rec.died = { biome: node.biome, level: level.id, type: level.type, depth }; break; }
    rec.levels++;
    if (level.type === LT.BOSS) rec.bossTurns[node.biome] = f.turn;
    if (!node.next.length) { rec.won = true; break; }
    // chests found mid-fight
    for (const l of f.foundLoot || []) { if (l.die) ai.offerDie(DB, run, l.die); if (l.item) ai.offerItem(DB, run, l.item); }
    // awards
    const arng = rng;
    if (level.type === LT.BOSS) {
      run.maxHealth += 1; run.health = run.maxHealth; run.maxDice += 1; run.poisoned = false;
      const die = rollDie(DB, arng, biome.difficulty, true); if (die) ai.offerDie(DB, run, die);
      if (arng.next() < 0.5) { const it = rollItem(DB, arng, biome.difficulty, true); if (it) ai.offerItem(DB, run, it); }
    } else if (level.type === LT.CHALLENGE) {
      if (f.turn <= level.turn_limit) {
        rec.challengeWins = (rec.challengeWins || 0) + 1;
        const it = arng.next() < 0.5 ? rollItem(DB, arng, biome.difficulty, true) : null;
        if (it) ai.offerItem(DB, run, it); else { const d = rollDie(DB, arng, biome.difficulty, true); if (d) ai.offerDie(DB, run, d); }
      }
    } else if (level.type === LT.NORMAL) {
      if (arng.next() < 0.53) { const d = rollDie(DB, arng, biome.difficulty, false); if (d) ai.offerDie(DB, run, d); }
    } else {
      // shop: stock by biome stage
      const stock = shopStock(DB, new G.RNG(node.seed + 7), biomeStage(biome));
      ai.shop(DB, run, stock.map(o => Object.assign(o, { price: PRICES[o.v.rarity] })));
    }
    // next level
    const nexts = node.next;
    const forced = opts.route ? nexts.filter(n => opts.route.includes(map[n].biome)) : [];
    index = forced.length === 1 && nexts.some(n => map[n].biome !== map[forced[0]].biome) ? forced[0] : ai.chooseNext(DB, run, map, nexts, rng);
    run.path.push(index);
  }
  rec.final = { hp: run.health, maxHp: run.maxHealth, dice: run.dice.slice(), equipment: run.equipment.slice(), gold: run.gold, sacrifices: run.sacrifices };
  return rec;
}

module.exports = { fightLevel, biomeStage, playRun, generateMap, populate, equipItem, rollDie, rollItem, PRICES };
