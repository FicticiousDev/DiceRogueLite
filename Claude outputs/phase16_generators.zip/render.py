import numpy as np, matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import importlib.util, sys
spec = importlib.util.spec_from_file_location("g", "/home/claude/work/gen/gen_designs.py"); g = importlib.util.module_from_spec(spec); spec.loader.exec_module(g)
ids = [d[0] for d in g.DESIGNS]
fig = plt.figure(figsize=(16, 9))
light = np.array([0.4, 0.8, 0.5]); light /= np.linalg.norm(light)
for k, id in enumerate(ids):
    m = g.build(id)
    ax = fig.add_subplot(3, 5, k + 1, projection="3d")
    polys, cols = [], []
    for mat in (0, 1):
        base = np.array([0.85, 0.85, 0.8]) if mat == 0 else np.array([0.85, 0.55, 0.2])
        for verts, ns in m.tris[mat]:
            fn = np.cross(verts[1] - verts[0], verts[2] - verts[0]); fn /= np.linalg.norm(fn)
            # matplotlib uses x,y,z with z up; map game y-up -> z
            polys.append([(v[0], v[2], v[1]) for v in verts])
            sh = 0.35 + 0.65 * max(0, np.dot([fn[0], fn[2], fn[1]], light))
            cols.append(tuple(base * sh))
    pc = Poly3DCollection(polys, facecolors=cols, edgecolors="none"); ax.add_collection3d(pc)
    ax.set_xlim(-.55, .55); ax.set_ylim(-.55, .55); ax.set_zlim(-.55, .55); ax.set_box_aspect((1, 1, 1))
    ax.view_init(elev=28, azim=-55); ax.axis("off"); ax.set_title(id)
plt.tight_layout(); plt.savefig("/tmp/claude-0/designs.png", dpi=70)
