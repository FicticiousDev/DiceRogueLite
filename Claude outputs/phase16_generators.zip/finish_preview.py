# Rough CPU port of die_finish.gdshaderinc: renders each finish on a cube (uncommon green) for a sanity check.
import numpy as np, re, glob, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
def fract(x): return x - np.floor(x)
def hash13(p):
    p = fract(p * 0.1031); d = (p * (p[..., ::-1] + 31.32)).sum(-1, keepdims=True); p = p + d
    return fract((p[..., 0] + p[..., 1]) * p[..., 2])
def noise3(p):
    i = np.floor(p); f = p - i; u = f * f * (3 - 2 * f)
    def h(o): return hash13(i + np.array(o, float))
    x00 = h([0,0,0]) + (h([1,0,0]) - h([0,0,0])) * u[..., 0]; x10 = h([0,1,0]) + (h([1,1,0]) - h([0,1,0])) * u[..., 0]
    x01 = h([0,0,1]) + (h([1,0,1]) - h([0,0,1])) * u[..., 0]; x11 = h([0,1,1]) + (h([1,1,1]) - h([0,1,1])) * u[..., 0]
    y0 = x00 + (x10 - x00) * u[..., 1]; y1 = x01 + (x11 - x01) * u[..., 1]
    return y0 + (y1 - y0) * u[..., 2]
def fbm(p):
    t = 0; a = 0.5
    for _ in range(4): t = t + noise3(p) * a; p = p * 2.03 + np.array([1.7, 9.2, 3.1]); a *= 0.5
    return t
def sstep(a, b, x): t = np.clip((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)
def spots(p, d, chance, r):
    on = (hash13(np.floor(p * d) + 13.7) >= 1 - chance).astype(float)
    return on * (1 - sstep(r * 0.5, r, np.linalg.norm(fract(p * d) - 0.5, axis=-1)))
def finish(F, P, N, V, body):
    p = P * 1.0; base = np.array(F["base"]) * (1 - F["tint"]) + body * F["tint"]
    fres = (1 - np.clip((N * V).sum(-1), 0, 1)) ** 3
    alb = np.broadcast_to(base, P.shape).copy(); em = np.zeros_like(P); pat = F["pattern"]; det = np.array(F["detail"])
    if pat == 1: s = noise3(p * np.array([60, 3, 3])); alb = base * (0.82 + 0.18 * s)[..., None]
    elif pat == 2: d = fbm(p * 3); alb = base * (0.3 + 0.25 * d)[..., None]; em = base * (fres * 0.9 + 0.12 * d)[..., None] + (spots(p, 28, 0.04, 0.3) * 0.35)[..., None]
    elif pat == 3: r = sstep(0.42, 0.62, fbm(p * 4)); fl = det * (0.65 + 0.35 * noise3(p * 25))[..., None]; alb = base * 0.9 * (1 - r)[..., None] + fl * r[..., None]
    elif pat == 4:
        w = np.sin(p[..., 0] * 5 + p[..., 1] * 3 + p[..., 2] * 2 + fbm(p * 2.5) * 9); v = 1 - sstep(0, 0.14, np.abs(w))
        l = base * 0.65 + 0.35; alb = l * (1 - v * 0.8)[..., None] + det * (v * 0.8)[..., None]
    elif pat == 5: alb = base * 0.6 + 0 * p; em = body * fres[..., None] * 0.7
    elif pat == 6:
        c = sstep(0.35, 0.8, fbm(p * 2.2)); n = noise3(p * 1.5)[..., None]; neb = (body * (1 - n * 0.45) + det * n * 0.45) * c[..., None]
        alb = base + neb * 0.25; em = neb * 0.55 + (spots(p, 26, 0.06, 0.22) * 1.6)[..., None]
    elif pat == 7: f = spots(p, 45, 0.18, 0.4)[..., None]; alb = base * (1 - f) + det * f
    elif pat == 8:
        rings = fract(np.linalg.norm(p[..., [0, 2]] + np.array([0.7, 0.3]), axis=-1) * 9 + fbm(p * 3) * 1.6); m = sstep(0.35, 0.75, rings)[..., None]
        alb = base * (1 - m) + (base * 0.5 * 0.5 + det * 0.5) * m
    elif pat == 9:
        rb = 0.5 + 0.5 * np.cos(6.2831 * ((fres * 1.3 + fbm(p * 2) * 0.5)[..., None] + np.array([0, 0.33, 0.67])))
        alb = base * 0.65 + 0.35 + 0 * p; em = rb * (fres * 0.45)[..., None]
    return alb, em
F = []
for path in sorted(glob.glob("/home/claude/work/DiceRogueLite/data/die_finishes/*.tres")):
    t = open(path).read(); g = lambda k, d: re.search(k + r" = (.*)", t).group(1) if re.search(k + r" = (.*)", t) else d
    col = lambda s: [float(x) for x in re.findall(r"[\d.]+", s)[:3]]
    F.append(dict(name=g("display_name", "")[1:-1], pattern=int(g("pattern", "0")), base=col(g("base_color", "Color(1,1,1,1)")), tint=float(g("tint", "1")), detail=col(g("detail_color", "Color(0.2,0.2,0.2,1)"))))
body = np.array([0.45, 0.78, 0.42]); res = 120
fig, axes = plt.subplots(2, 6, figsize=(15, 5.5))
# three visible faces of a cube in an isometric-ish view
light = np.array([0.5, 0.8, 0.4]); light /= np.linalg.norm(light); V0 = np.array([0.6, 0.55, 0.6]); V0 /= np.linalg.norm(V0)
for ax, f in zip(axes.flat, F):
    img = np.zeros((2 * res, 2 * res, 3)) + 0.12
    u = np.linspace(-0.5, 0.5, res)
    A, B = np.meshgrid(u, u)
    faces = [(np.stack([A, np.full_like(A, 0.5), B], -1), np.array([0, 1, 0])), (np.stack([np.full_like(A, 0.5), -B, A], -1), np.array([1, 0, 0])), (np.stack([A, -B, np.full_like(A, 0.5)], -1), np.array([0, 0, 1]))]
    tiles = []
    for P, n in faces:
        N = np.broadcast_to(n, P.shape); V = np.broadcast_to(V0, P.shape)
        alb, em = finish(f, P, N, V, body)
        col = alb * (0.35 + 0.65 * max(0, n @ light)) + em
        tiles.append(np.clip(col, 0, 1))
    img[:res, :res] = tiles[0]; img[res:, :res] = tiles[1]; img[res:, res:] = tiles[2]; img[:res, res:] = tiles[2][::-1]
    ax.imshow(img); ax.set_title(f["name"]); ax.axis("off")
plt.tight_layout(); plt.savefig("/tmp/claude-0/finishes.png", dpi=60); print("ok")
