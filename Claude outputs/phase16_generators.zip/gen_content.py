# Claude-side generator for Phase 16 content: new characters, their dice, unlock challenges.
import os
ROOT = "/home/claude/work/DiceRogueLite"
SYM = "ATTACK DEFENCE MOVE CRIT INSTA_KILL DODGE TELEPORT BUFF STUN POISON PENETRATE RANGE".split()

def die_tres(id, name, rarity, faces):
    out = ['[gd_resource type="Resource" script_class="DieType" format=3]', '',
           '[ext_resource type="Script" path="res://resources/dice/die_face.gd" id="1_face"]',
           '[ext_resource type="Script" path="res://resources/dice/face_symbol.gd" id="2_symbol"]',
           '[ext_resource type="Script" path="res://resources/dice/die_type.gd" id="3_type"]', '']
    face_ids = []
    for fi, face in enumerate(faces):
        sym_ids = []
        for si, (sym, count) in enumerate(face):
            sid = f"Symbol_{fi}_{si}"; sym_ids.append(sid)
            out.append(f'[sub_resource type="Resource" id="{sid}"]')
            out.append('script = ExtResource("2_symbol")')
            if SYM.index(sym): out.append(f'symbol = {SYM.index(sym)}')
            if count != 1: out.append(f'count = {count}')
            out.append('')
        fid = f"Face_{fi}"; face_ids.append(fid)
        out.append(f'[sub_resource type="Resource" id="{fid}"]')
        out.append('script = ExtResource("1_face")')
        out.append('symbols = Array[ExtResource("2_symbol")]([%s])' % ", ".join(f'SubResource("{s}")' for s in sym_ids))
        out.append('')
    out += ['[resource]', 'script = ExtResource("3_type")', f'id = &"{id}"', f'display_name = "{name}"', f'rarity = {rarity}',
            'faces = Array[ExtResource("1_face")]([%s])' % ", ".join(f'SubResource("{f}")' for f in face_ids), '']
    open(f"{ROOT}/data/dice/{id}.tres", "w").write("\n".join(out))

A, D, M = "ATTACK", "DEFENCE", "MOVE"
DICE = {
    "mantra": ("Mantra Die", [[(A, 2)], [(A, 1), ("STUN", 1)], [(D, 2)], [(D, 2)], [("DODGE", 1)], [(M, 2)]]),
    "tumble": ("Tumble Die", [[(M, 3)], [(M, 2), ("TELEPORT", 1)], [("DODGE", 1)], [(A, 2)], [(A, 2)], [(A, 1), ("CRIT", 1)]]),
    "cinder": ("Cinder Die", [[(A, 2)], [(A, 2)], [(A, 2)], [(A, 1), ("CRIT", 1)], [(D, 2)], [(M, 2)]]),
    "rift": ("Rift Die", [[(M, 3), ("TELEPORT", 1)], [("DODGE", 1)], [("DODGE", 1)], [(A, 2)], [(A, 1), ("CRIT", 1)], [(A, 2)]]),
    "rampart": ("Rampart Die", [[(D, 3)], [(D, 2)], [(D, 2)], [(A, 2)], [(A, 2)], [(M, 1)]]),
    "scope": ("Scope Die", [[(A, 2)], [(A, 2)], [(A, 2)], [(A, 1), ("PENETRATE", 1)], [(D, 1)], [(M, 2)]]),
}

# kind: script file, props (key -> literal)
def ability(sid, script, id, name, desc, props):
    return (sid, script, [f'id = &"{id}"', f'display_name = "{name}"', f'description = "{desc}"'] + props)

COOL = ["active = true", "cooldown = 3"]
CHARS = [
    ("monk", "Monk", 3, "Color(1, 0.85, 0.55, 1)", 1, "mantra", [
        ability("passive", "regenerate_ability", "inner_peace", "Inner Peace", "Passive: heal 1 at the end of every round, even when you took damage.", []),
        ability("active", "redirect_ability", "redirect", "Redirect", "Every 3 turns, when an enemy strikes back: send its hit to any enemy as close to you as the striker is.", COOL + ["use = 1"]),
    ]),
    ("acrobat", "Acrobat", 4, "Color(1, 0.6, 0.8, 1)", 1, "tumble", [
        ability("passive", "die_bonus_ability", "nimble", "Nimble", "Passive: every movement die you roll gets +1 move.", ["category = 2"]),
        ability("active", "dash_ability", "leap", "Leap", "Every 3 turns: leap up to 4 tiles (like a teleport), dealing 3 damage to every enemy you leap over.", COOL + ["use = 3", "reach = 4", "damage = 3"]),
    ]),
    ("pyro", "Pyro", 5, "Color(1, 0.5, 0.3, 1)", 3, "cinder", [
        ability("passive", "enemy_range_ability", "smoke", "Smoke", "Passive: ranged enemies have 1 less range.", []),
        ability("active", "attack_modifier_ability", "ignite", "Ignite", "Every 3 turns: an attack sets what it hits on fire - half the damage dealt again at the start of the next round.", COOL + ["fire = true"]),
    ]),
    ("void_dancer", "Void Dancer", 6, "Color(0.7, 0.55, 1, 1)", 1, "rift", [
        ability("passive", "evasion_ability", "blur", "Blur", "Passive: enemy attacks are twice as likely to miss you.", []),
        ability("active", "dash_ability", "rift_step", "Rift Step", "Every 3 turns: teleport up to 5 tiles; your next attack this turn is a crit.", COOL + ["use = 3", "reach = 5", 'boosts = Array[StringName]([&"crit"])']),
    ]),
    ("tank", "Tank", 7, "Color(0.6, 0.66, 0.72, 1)", 1, "rampart", [
        ability("passive", "extra_die_ability", "iron_wall", "Iron Wall", "Passive: you always roll an extra defence die showing 2.", ["symbol = 1", "count = 2", "rarity = 1"]),
        ability("active", "dash_ability", "shield_charge", "Shield Charge", "Every 3 turns: charge up to 3 tiles (like a teleport), dealing 3 damage that ignores defence to every enemy in the way and knocking them aside.", COOL + ["use = 3", "reach = 3", "damage = 3", "ignore_defence = true", "knockback = true"]),
    ]),
    ("sniper", "Sniper", 8, "Color(0.75, 0.9, 0.6, 1)", 5, "scope", [
        ability("passive", "range_damage_ability", "deadeye", "Deadeye", "Passive: +1 damage against enemies 3 tiles away, +2 at 4 and +3 at 5 or more, added after crits.", []),
        ability("active", "boost_ability", "armour_piercer", "Armour Piercer", "Every 3 turns, as an action: your attacks for the rest of the turn ignore defence.", COOL + ["use = 2"]),
    ]),
]

def char_tres(id, name, order, tint, rng, die, abilities, unlocked=False):
    scripts = sorted({a[1] for a in abilities})
    out = ['[gd_resource type="Resource" script_class="CharacterData" format=3]', '',
           '[ext_resource type="Script" path="res://resources/abilities/ability.gd" id="1_ability"]',
           '[ext_resource type="Script" path="res://resources/character_data.gd" id="2_character"]']
    for i, sc in enumerate(scripts):
        out.append(f'[ext_resource type="Script" path="res://resources/abilities/{sc}.gd" id="{i + 3}_{sc}"]')
    out.append('')
    for sid, sc, props in abilities:
        out.append(f'[sub_resource type="Resource" id="Ability_{sid}"]')
        out.append(f'script = ExtResource("{scripts.index(sc) + 3}_{sc}")')
        out += props
        out.append('')
    out += ['[resource]', 'script = ExtResource("2_character")', f'id = &"{id}"', f'order = {order}', f'display_name = "{name}"', f'tint = {tint}']
    if rng != 1: out.append(f'attack_range = {rng}')
    out.append('abilities = Array[ExtResource("1_ability")]([%s])' % ", ".join(f'SubResource("Ability_{a[0]}")' for a in abilities))
    out.append(f'starting_dice = Array[StringName]([&"movement", &"defence", &"attack", &"{die}", &"{die}"])')
    if not unlocked: out.append('starts_unlocked = false')
    out.append('')
    open(f"{ROOT}/data/characters/{id}.tres", "w").write("\n".join(out))

# Base characters rewritten with cooldown actives (Mage's passive and active swapped)
BASE = [
    ("knight", "Knight", 0, "Color(0.55, 0.75, 1, 1)", 1, "guardian", [
        ability("passive", "defence_bonus_ability", "bulwark", "Bulwark", "Passive: every defence die you roll gets +1 shield.", []),
        ability("active", "block_attack_ability", "shield_block", "Shield Block", "Every 3 turns: completely block one attack.", COOL + ["use = 1"]),
    ]),
    ("assassin", "Assassin", 1, "Color(0.6, 1, 0.6, 1)", 1, "viper", [
        ability("passive", "strike_first_ability", "quick_strike", "Quick Strike", "Passive: you always strike first, even against enemies that strike first, and your first attack each turn is a crit.", []),
        ability("active", "double_attack_ability", "ambush", "Ambush", "Every 3 turns: double the highest die of one attack (stacks with a crit).", COOL),
    ]),
    ("mage", "Mage", 2, "Color(1, 0.7, 1, 1)", 3, "phase", [
        ability("passive", "ignore_defence_ability", "arcane", "Arcane", "Passive: your attacks ignore enemy defence.", []),
        ability("active", "area_attack_ability", "blast", "Blast", "Every 3 turns: an attack also hits every tile next to the target for the same damage.", COOL),
    ]),
]

# Unlock challenges: (id, description, reward kind 0 char / 1 design, reward id, stat, subjects, mode 0 total / 1 each, target)
BOSSES = ["warlord", "overseer", "brood_mother", "colossus", "tyrant", "overlord"]
CHALLENGES = [
    ("unlock_monk", "Win a run without taking any damage from a boss.", 0, "monk", "flawless_victory", [], 0, 1),
    ("unlock_acrobat", "Dodge an attack from every boss.", 0, "acrobat", "dodged_boss", BOSSES, 1, 1),
    ("unlock_pyro", "Defeat the Tyrant (Ashlands boss) 5 times.", 0, "pyro", "boss_defeated", ["tyrant"], 0, 5),
    ("unlock_void_dancer", "Win a run.", 0, "void_dancer", "victories", [], 0, 1),
    ("unlock_tank", "Defeat a boss with only 1 health left and fewer dice than your pool can hold.", 0, "tank", "clutch_boss_kill", [], 0, 1),
    ("unlock_sniper", "Kill 100 ranged enemies.", 0, "sniper", "ranged_kill", [], 0, 100),
    # Die designs
    ("design_pebble", "Recover 100 health.", 1, "pebble", "healed", [], 0, 100),
    ("design_thunder", "Stun enemies 100 times.", 1, "thunder", "stun", [], 0, 100),
    ("design_venom", "Poison enemies 100 times.", 1, "venom", "poison", [], 0, 100),
    ("design_iron", "Defeat the Warlord (Grasslands boss) 10 times.", 1, "iron", "boss_defeated", ["warlord"], 0, 10),
    ("design_sandstorm", "Defeat the Overseer (Badlands boss) 10 times.", 1, "sandstorm", "boss_defeated", ["overseer"], 0, 10),
    ("design_bog", "Defeat the Brood Mother (Marsh boss) 20 times.", 1, "bog", "boss_defeated", ["brood_mother"], 0, 20),
    ("design_glacier", "Defeat the Colossus (Frost boss) 10 times.", 1, "glacier", "boss_defeated", ["colossus"], 0, 10),
    ("design_inferno", "Defeat the Tyrant (Ashlands boss) 10 times.", 1, "inferno", "boss_defeated", ["tyrant"], 0, 10),
    ("design_void", "Defeat the Overlord (Abyss boss) 5 times.", 1, "void", "boss_defeated", ["overlord"], 0, 5),
    ("design_gilded", "Land 250 critical hits.", 1, "gilded", "crits", [], 0, 250),
    ("design_blink", "Teleport 100 times.", 1, "blink", "teleport", [], 0, 100),
    ("design_ember", "Set enemies on fire 50 times.", 1, "ember", "burn", [], 0, 50),
    ("design_crowned", "Win 5 runs.", 1, "crowned", "victories", [], 0, 5),
]

def challenge_tres(id, desc, kind, reward, stat, subjects, mode, target):
    out = ['[gd_resource type="Resource" script_class="UnlockChallenge" format=3]', '',
           '[ext_resource type="Script" path="res://resources/unlock_challenge.gd" id="1_challenge"]', '',
           '[resource]', 'script = ExtResource("1_challenge")', f'id = &"{id}"', f'description = "{desc}"']
    if kind: out.append(f'reward = {kind}')
    out += [f'reward_id = &"{reward}"', f'stat = &"{stat}"']
    if subjects: out.append('subjects = Array[StringName]([%s])' % ", ".join(f'&"{s}"' for s in subjects))
    if mode: out.append(f'mode = {mode}')
    if target != 1: out.append(f'target = {target}')
    out.append('')
    os.makedirs(f"{ROOT}/data/challenges", exist_ok=True)
    open(f"{ROOT}/data/challenges/{id}.tres", "w").write("\n".join(out))

if __name__ == "__main__":
    for id, (name, faces) in DICE.items():
        die_tres(id, name, 1, faces)
    for c in CHARS: char_tres(*c)
    for c in BASE: char_tres(*c, unlocked=True)
    for c in CHALLENGES: challenge_tres(*c)
    print("ok")
