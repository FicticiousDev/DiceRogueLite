# Claude-side generator: die design meshes (OBJ, surface 0 = main body, surface 1 = trim) and their DieDesign .tres.
import numpy as np, os, itertools
from scipy.spatial import ConvexHull
ROOT = "/home/claude/work/DiceRogueLite"
OUT = ROOT + "/assets/dice/designs"

UV = {0: (1, 2), 1: (2, 0), 2: (0, 1)}

class Mesh:
    def __init__(self): self.tris = {0: [], 1: []}   # mat -> list of (3 verts, 3 normals)
    def tri(self, a, b, c, mat, n=None):
        a, b, c = map(np.asarray, (a, b, c))
        fn = np.cross(b - a, c - a)
        if np.linalg.norm(fn) < 1e-12: return
        fn = fn / np.linalg.norm(fn)
        if n is None: ns = [fn] * 3
        else:
            ns = [np.asarray(x, float) / np.linalg.norm(x) for x in n]
            if np.dot(fn, sum(ns)) < 0:
                b, c = c, b; ns = [ns[0], ns[2], ns[1]]
        self.tris[mat].append(((a, b, c), ns))
    def quad(self, a, b, c, d, mat, n=None):
        self.tri(a, b, c, mat, None if n is None else n[:3])
        self.tri(a, c, d, mat, None if n is None else [n[0], n[2], n[3]])
    def box(self, lo, hi, mat):
        lo, hi = np.asarray(lo, float), np.asarray(hi, float)
        for axis in range(3):
            for sign in (-1, 1):
                u, v = UV[axis]
                if sign < 0: u, v = v, u
                pts = []
                for (su, sv) in [(0, 0), (1, 0), (1, 1), (0, 1)]:
                    p = np.zeros(3); p[axis] = hi[axis] if sign > 0 else lo[axis]
                    p[u] = hi[u] if su else lo[u]; p[v] = hi[v] if sv else lo[v]
                    pts.append(p)
                self.quad(*pts, mat)
    def sphere(self, c, r, mat, seg=12, scale=(1, 1, 1)):
        c = np.asarray(c, float); s = np.asarray(scale, float)
        def pt(i, j):
            th = np.pi * i / seg; ph = 2 * np.pi * j / (2 * seg)
            d = np.array([np.sin(th) * np.cos(ph), np.cos(th), np.sin(th) * np.sin(ph)])
            return c + r * d * s, d / s
        for i in range(seg):
            for j in range(2 * seg):
                (a, na), (b, nb), (cc, nc), (d, nd) = pt(i, j), pt(i + 1, j), pt(i + 1, j + 1), pt(i, j + 1)
                self.tri(a, cc, b, mat, [na, nc, nb]); self.tri(a, d, cc, mat, [na, nd, nc])
    def hull(self, points, classify):
        pts = np.asarray(points, float); h = ConvexHull(pts); centre = pts.mean(0)
        for simplex, eq in zip(h.simplices, h.equations):
            a, b, c = pts[simplex]; n = eq[:3]
            if np.dot(np.cross(b - a, c - a), n) < 0: b, c = c, b
            self.tri(a, b, c, classify(n))
    def rounded_box(self, half, r, mat, steps=8):
        # every face as a grid, pushed onto the rounded shape
        a = half - r
        ts = sorted(set(np.concatenate([np.linspace(-half, -a, steps), np.linspace(-a, a, 3), np.linspace(a, half, steps)]).round(9)))
        for axis in range(3):
            for sign in (-1, 1):
                u, v = UV[axis]
                if sign < 0: u, v = v, u
                grid = {}
                for i, tu in enumerate(ts):
                    for j, tv in enumerate(ts):
                        q = np.zeros(3); q[axis] = sign * half; q[u] = tu; q[v] = tv
                        inner = np.clip(q, -a, a); d = q - inner; n = d / np.linalg.norm(d)
                        grid[i, j] = (inner + r * n, n)
                for i in range(len(ts) - 1):
                    for j in range(len(ts) - 1):
                        p = [grid[i, j], grid[i + 1, j], grid[i + 1, j + 1], grid[i, j + 1]]
                        self.quad(*[x[0] for x in p], mat, [x[1] for x in p])
    def write(self, path):
        lines = ["# Generated die design mesh. Surface 0: main body, surface 1: trim", "mtllib designs.mtl"]
        vs, ns, faces = {}, {}, {0: [], 1: []}
        def index(table, x):
            key = tuple(np.round(x, 5) + 0.0)
            if key not in table: table[key] = len(table) + 1
            return table[key]
        for mat in (0, 1):
            for verts, norms in self.tris[mat]:
                faces[mat].append([(index(vs, v), index(ns, n)) for v, n in zip(verts, norms)])
        lines += ["v %g %g %g" % k for k in vs]
        lines += ["vn %g %g %g" % k for k in ns]
        for mat in (0, 1):
            if not faces[mat]: continue
            lines.append("usemtl %s" % ("main", "trim")[mat])
            lines += ["f " + " ".join("%d//%d" % p for p in f) for f in faces[mat]]
        open(path, "w").write("\n".join(lines) + "\n")

AX = [np.eye(3)[i] for i in range(3)]
def axis_aligned(n): return max(abs(n)) > 0.999

def perms(base):
    out = set()
    for p in itertools.permutations(base):
        for s in itertools.product((-1, 1), repeat=3):
            out.add(tuple(a * b for a, b in zip(p, s)))
    return list(out)

def edge_bars(m, inner, outer, mat):
    # 12 square bars along the cube's edges, cross-section [inner, outer]
    for axis in range(3):
        u, v = [i for i in range(3) if i != axis]
        for su in (-1, 1):
            for sv in (-1, 1):
                lo = np.zeros(3); hi = np.zeros(3)
                lo[axis], hi[axis] = -outer, outer
                lo[u], hi[u] = sorted([su * inner, su * outer]); lo[v], hi[v] = sorted([sv * inner, sv * outer])
                m.box(lo, hi, mat)

def per_face(fn):
    # calls fn(axis, sign, u, v) for each of the 6 faces
    for axis in range(3):
        for sign in (-1, 1):
            u, v = [i for i in range(3) if i != axis]
            fn(axis, sign, u, v)

UV = {0: (1, 2), 1: (2, 0), 2: (0, 1)}
def face_point(axis, sign, a, b, h):
    u, v = UV[axis]
    p = np.zeros(3); p[axis] = sign * h; p[u] = a; p[v] = b; return p

def ring(m, inner, outer, z0, z1, mat, seg=32):
    def one(axis, sign, u, v):
        for k in range(seg):
            t0, t1 = 2 * np.pi * k / seg, 2 * np.pi * (k + 1) / seg
            c0, s0, c1, s1 = np.cos(t0), np.sin(t0), np.cos(t1), np.sin(t1)
            P = lambda r, c, s, z: face_point(axis, sign, r * c, r * s, z)
            top = [P(inner, c0, s0, z1), P(outer, c0, s0, z1), P(outer, c1, s1, z1), P(inner, c1, s1, z1)]
            outs = [P(outer, c0, s0, z0), P(outer, c1, s1, z0), P(outer, c1, s1, z1), P(outer, c0, s0, z1)]
            ins = [P(inner, c0, s0, z1), P(inner, c1, s1, z1), P(inner, c1, s1, z0), P(inner, c0, s0, z0)]
            for q in (top, outs, ins):
                n = np.cross(q[1] - q[0], q[2] - q[0]); centre = sum(q) / 4
                if np.dot(n, centre - face_point(axis, sign, 0, 0, (z0 + z1) / 2)) < 0 and q is not top: q = q[::-1]
                if q is top and np.dot(np.cross(q[1] - q[0], q[2] - q[0]), AX[axis] * sign) < 0: q = q[::-1]
                m.quad(*q, mat)
    per_face(one)

def square_frame(m, inner, outer, z0, z1, mat):
    def one(axis, sign, u, v):
        for lo, hi in [((-outer, -outer), (outer, -inner)), ((-outer, inner), (outer, outer)), ((-outer, -inner), (-inner, inner)), ((inner, -inner), (outer, inner))]:
            a = face_point(axis, sign, lo[0], lo[1], 0); b = face_point(axis, sign, hi[0], hi[1], 0)
            lo3 = np.minimum(a, b); hi3 = np.maximum(a, b)
            lo3[axis], hi3[axis] = sorted([sign * z0, sign * z1])
            m.box(lo3, hi3, mat)
    per_face(one)

def build(name):
    m = Mesh()
    if name == "chamfer":
        c = 0.07; m.hull(perms((0.5, 0.5 - c, 0.5 - c)), lambda n: 0)
    elif name == "inferno":
        c = 0.1; m.hull(perms((0.5, 0.5 - c, 0.5 - c)), lambda n: 0 if axis_aligned(n) else 1)
    elif name == "glacier":
        t = 0.2; m.hull(perms((0.5, 0.5, 0.5 - t)), lambda n: 0 if axis_aligned(n) else 1)
    elif name == "ember":
        # truncated corners, each capped with a three-sided pyramid out to the cube's corner
        t = 0.22; m.hull(perms((0.5, 0.5, 0.5 - t)), lambda n: 0)
        m.tris[0] = [tr for tr in m.tris[0] if axis_aligned(np.cross(tr[0][1] - tr[0][0], tr[0][2] - tr[0][0]) / np.linalg.norm(np.cross(tr[0][1] - tr[0][0], tr[0][2] - tr[0][0])))]
        for s in itertools.product((-1, 1), repeat=3):
            s = np.array(s, float); apex = 0.5 * s
            base = [apex - s * t * AX[i] for i in range(3)]
            for i in range(3):
                a, b = base[i], base[(i + 1) % 3]
                n = np.cross(b - a, apex - a)
                if np.dot(n, s) < 0: a, b = b, a
                m.tri(a, b, apex, 1)
    elif name == "pebble":
        m.rounded_box(0.5, 0.2, 0)
    elif name == "thunder":
        m.rounded_box(0.5, 0.12, 0)
        for s in itertools.product((-1, 1), repeat=3): m.sphere(np.array(s) * 0.4, 0.1, 1, seg=10)
    elif name == "venom":
        m.box([-0.485] * 3, [0.485] * 3, 0); ring(m, 0.40, 0.47, 0.48, 0.5, 1)
    elif name == "iron":
        m.box([-0.485] * 3, [0.485] * 3, 0); edge_bars(m, 0.43, 0.5, 1)
    elif name == "crowned":
        m.box([-0.485] * 3, [0.485] * 3, 0); edge_bars(m, 0.44, 0.5, 1)
        for s in itertools.product((-1, 1), repeat=3): m.sphere(np.array(s) * 0.435, 0.065, 1, seg=8)
    elif name == "sandstorm":
        m.box([-0.485] * 3, [0.485] * 3, 0); square_frame(m, 0.38, 0.47, 0.48, 0.5, 1)
    elif name == "bog":
        m.box([-0.45] * 3, [0.45] * 3, 1)
        def plateau(axis, sign, u, v):
            lo = np.zeros(3); hi = np.zeros(3); lo[u], hi[u] = -0.39, 0.39; lo[v], hi[v] = -0.39, 0.39
            lo[axis], hi[axis] = sorted([sign * 0.44, sign * 0.5]); m.box(lo, hi, 0)
        per_face(plateau)
    elif name == "void":
        m.box([-0.42] * 3, [0.42] * 3, 0); edge_bars(m, 0.4, 0.5, 1)
    elif name == "gilded":
        m.box([-0.485] * 3, [0.485] * 3, 0)
        def rivets(axis, sign, u, v):
            for a, b in itertools.product((-0.4, 0.4), repeat=2):
                c = face_point(axis, sign, a, b, 0.48); sc = np.ones(3); sc[axis] = 0.44
                m.sphere(c, 0.045, 1, seg=6, scale=sc)
        per_face(rivets)
    elif name == "blink":
        # corners notched out: each face is a plus shape; the notch walls are trim
        n = 0.15; k = 0.5 - n
        def plus(axis, sign, u, v):
            for (a0, a1, b0, b1) in [(-k, k, -0.5, 0.5), (-0.5, -k, -k, k), (k, 0.5, -k, k)]:
                q = [face_point(axis, sign, x, y, 0.5) for x, y in [(a0, b0), (a1, b0), (a1, b1), (a0, b1)]]
                if np.dot(np.cross(q[1] - q[0], q[2] - q[0]), AX[axis] * sign) < 0: q = q[::-1]
                m.quad(*q, 0)
        per_face(plus)
        for s in itertools.product((-1, 1), repeat=3):
            s = np.array(s, float)
            for i in range(3):   # the notch wall facing back along axis i: at |x_i| = k, other two coords in [k, 0.5]
                j, l = [x for x in range(3) if x != i]
                q = []
                for (a, b) in [(k, k), (0.5, k), (0.5, 0.5), (k, 0.5)]:
                    p = np.zeros(3); p[i] = s[i] * k; p[j] = s[j] * a; p[l] = s[l] * b; q.append(p)
                if np.dot(np.cross(q[1] - q[0], q[2] - q[0]), AX[i] * s[i]) < 0: q = q[::-1]
                m.quad(*q, 1)
    return m

# id, name, face_size, face_offset, starts_unlocked
DESIGNS = [
    ("chamfer", "Chamfer", 0.84, 0.5, True),
    ("pebble", "Pebble", 0.58, 0.5, False),
    ("thunder", "Thunder", 0.62, 0.5, False),
    ("venom", "Venom", 0.55, 0.485, False),
    ("iron", "Iron", 0.8, 0.485, False),
    ("sandstorm", "Sandstorm", 0.72, 0.485, False),
    ("bog", "Bog", 0.74, 0.5, False),
    ("glacier", "Glacier", 0.74, 0.5, False),
    ("inferno", "Inferno", 0.78, 0.5, False),
    ("ember", "Ember", 0.76, 0.5, False),
    ("void", "Void", 0.76, 0.42, False),
    ("gilded", "Gilded", 0.68, 0.485, False),
    ("blink", "Blink", 0.68, 0.5, False),
    ("crowned", "Crowned", 0.8, 0.485, False),
]

# ----- checks -----
def ray_hits(m, origin, d):
    best = None
    for mat in (0, 1):
        for verts, _ in m.tris[mat]:
            a, b, c = verts; e1, e2 = b - a, c - a; p = np.cross(d, e2); det = np.dot(e1, p)
            if abs(det) < 1e-12: continue
            t0 = origin - a; u = np.dot(t0, p) / det
            if u < -1e-9 or u > 1 + 1e-9: continue
            q = np.cross(t0, e1); v = np.dot(d, q) / det
            if v < -1e-9 or u + v > 1 + 1e-9: continue
            t = np.dot(e2, q) / det
            if t > 0 and (best is None or t < best[0]): best = (t, mat)
    return best

def check(id, m, face_size, offset):
    allv = np.array([v for mat in (0, 1) for verts, _ in m.tris[mat] for v in verts])
    assert np.all(np.abs(allv) <= 0.5 + 1e-6), (id, np.abs(allv).max())
    h = face_size / 2
    for axis in range(3):
        for sign in (-1, 1):
            for a, b in [(0, 0), (h, h), (-h, h), (h, -h), (-h, -h), (h, 0), (0, -h)]:
                o = face_point(axis, sign, a * 0.999, b * 0.999, 2.0) if False else None
                u, v = [i for i in range(3) if i != axis]
                o = np.zeros(3); o[axis] = sign * 2.0; o[u] = a * 0.999; o[v] = b * 0.999
                d = np.zeros(3); d[axis] = -sign
                hit = ray_hits(m, o, d)
                assert hit is not None, (id, "no hit", axis, sign, a, b)
                depth = 2.0 - hit[0]
                assert abs(depth - offset) < 2e-3 and hit[1] == 0, (id, "face area not flat main body", axis, sign, a, b, depth, hit)
    # outward normals: most flat normals should point away from the centre
    bad = 0; total = 0
    for mat in (0, 1):
        for verts, ns in m.tris[mat]:
            c = sum(verts) / 3; total += 1
            fn = np.cross(verts[1] - verts[0], verts[2] - verts[0])
            if np.dot(fn, c) < -1e-9: bad += 1
    return bad, total, len(m.tris[1]) > 0

def tres(id, name, size, offset, unlocked):
    out = ['[gd_resource type="Resource" script_class="DieDesign" format=3]', '',
           f'[ext_resource type="Mesh" path="res://assets/dice/designs/{id}.obj" id="1_mesh"]',
           '[ext_resource type="Script" path="res://resources/dice/die_design.gd" id="2_design"]', '',
           '[resource]', 'script = ExtResource("2_design")', f'id = &"{id}"', f'display_name = "{name}"',
           'mesh = ExtResource("1_mesh")', f'face_size = {size}']
    if offset != 0.5: out.append(f'face_offset = {offset}')
    if not unlocked: out.append('starts_unlocked = false')
    out.append('')
    open(f"{ROOT}/data/die_designs/{id}.tres", "w").write("\n".join(out))

if __name__ == "__main__":
    import sys
    os.makedirs(OUT, exist_ok=True)
    open(f"{OUT}/designs.mtl", "w").write("newmtl main\nKd 0.9 0.9 0.85\n\nnewmtl trim\nKd 0.8 0.6 0.3\n")
    only = sys.argv[1:]
    for id, name, size, offset, unlocked in DESIGNS:
        if only and id not in only: continue
        m = build(id)
        bad, total, trim = check(id, m, size, offset)
        m.write(f"{OUT}/{id}.obj")
        tres(id, name, size, offset, unlocked)
        print(f"{id:10} tris {total:5}  inward-facing {bad:4}  trim {trim}")
