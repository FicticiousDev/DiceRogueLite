import base64,struct,re,glob,os
ROOT=__import__('os').environ.get('PROJECT', '.')  # project folder (set PROJECT)
MARK=['START','ENEMY','OBST','EXIT','LOOT','SHOP','BANK','BOSSPT']
TERR=['N','D','X','W','#']
def decode(b64):
    b=base64.b64decode(b64); out={}
    assert struct.unpack('<H',b[:2])[0]==0
    for i in range(2,len(b),12):
        x,y,src,ax,ay,alt=struct.unpack('<hhHHHH',b[i:i+12]); out[(x,y)]=ax
    return out
def encode(cells):
    b=struct.pack('<H',0)
    for (x,y),ax in sorted(cells.items()):
        b+=struct.pack('<hhHHHH',x,y,0,ax,0,0)
    return base64.b64encode(b).decode()
def load(path):
    t=open(path).read()
    arr=re.findall(r'tile_map_data = PackedByteArray\("([^"]*)"\)',t)
    return t,decode(arr[0]),decode(arr[1])
def dist(a,b):
    dx=a[0]-b[0];dy=a[1]-b[1];return (abs(dx)+abs(dy)+abs(dx+dy))//2
NB=[(1,-1),(1,0),(0,1),(-1,1),(-1,0),(0,-1)]
