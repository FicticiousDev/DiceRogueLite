"""Reworks every level: start near the middle, layout grown to fit, enemies spread around it (two points close,
the rest further out), loot tucked away on the edges, no exit markers."""
from lvl import *
import random, math, os, sys
START,ENEMY,OBST,EXIT,LOOT,SHOP,BANK,BOSSPT=range(8)
N,D,X,W,WALL=range(5)
COST={N:1,D:2,X:3,W:2,WALL:-1}
# Radius from the start each stage's levels grow to (biome bosses go by their biome's stage)
RADIUS={1:5,2:6,3:6,4:7}
# Share of the first rework's grown size the levels now grow to
SHRINK=0.82
# The start goes within this many tiles of the middle, and at least EDGE_GAP tiles in from the edge where it can
START_SPREAD=3
EDGE_GAP=3
BIOME_STAGE={'grasslands':1,'badlands':2,'marsh':2,'frost':3,'ashlands':3,'abyss':4}

def stage_of(name):
    if name.startswith('boss_') and '_s' not in name: return BIOME_STAGE[name[5:]]
    m=re.search(r'_s(\d)_',name); return int(m.group(1)) if m else 0
def nbs(c): return [(c[0]+a,c[1]+b) for a,b in NB]
def ecc(c,cells): return max(dist(c,o) for o in cells)
def angle(a,b):
    x,y=b[0]-a[0]+(b[1]-a[1])/2, (b[1]-a[1])*math.sqrt(3)/2
    return math.atan2(y,x)
def adiff(a,b): d=abs(a-b)%(2*math.pi); return min(d,2*math.pi-d)
def walkable(lay,mk,c): return c in lay and lay[c]!=WALL and mk.get(c)!=OBST
def costs_from(lay,mk,s):
    import heapq
    best={s:0}; q=[(0,s)]
    while q:
        d,c=heapq.heappop(q)
        if d>best[c]: continue
        for n in nbs(c):
            if not walkable(lay,mk,n) or mk.get(n) in (SHOP,BANK): continue
            nd=d+COST[lay[n]]
            if nd<best.get(n,1e9): best[n]=nd; heapq.heappush(q,(nd,n))
    return best
def connected(lay,mk,s):
    reach=costs_from(lay,mk,s)
    return all(c in reach for c in lay if walkable(lay,mk,c) and mk.get(c) not in (SHOP,BANK))

def grow(lay,rng,R):
    """Adds tiles around the layout's middle, at most [R] from it, until it has ~1.6x the tiles (and some room)."""
    centre=min(lay,key=lambda c:(ecc(c,lay),dist(c,(0,0)),c))
    area=1+3*R*(R+1)
    target=round(min(max(round(len(lay)*1.6),round(area*0.55)),round(area*0.72))*SHRINK)
    while len(lay)<target:
        front=sorted({n for c in lay for n in nbs(c) if n not in lay and dist(n,centre)<=R})
        if not front: break
        # Favour pockets (smooth outline) and the side nearer the middle (keeps it roughly centred)
        weights=[sum(o in lay for o in nbs(n))**2*(1.0+(R-dist(n,centre))*0.3) for n in front]
        n=rng.choices(front,weights)[0]
        patch=[lay[o] for o in nbs(n) if o in lay and lay[o]!=N]
        lay[n]=rng.choice(patch) if patch and rng.random()<0.3 else N
    # Fill pockets, trim spurs
    for _ in range(2):
        for n in sorted({n for c in lay for n in nbs(c) if n not in lay}):
            if sum(o in lay for o in nbs(n))>=4: lay[n]=N
        for c in sorted(lay):
            if sum(o in lay for o in nbs(c))<=1: del lay[c]
    # Drop pockets walled off from the middle, then walls left with nothing walkable beside them
    reach=costs_from(lay,{},centre) if lay.get(centre)!=WALL else costs_from(lay,{},next(c for c in lay if lay[c]!=WALL))
    for c in sorted(lay):
        if lay[c]!=WALL and c not in reach: del lay[c]
    for c in sorted(lay):
        if lay[c]==WALL and not any(o in lay and lay[o]!=WALL for o in nbs(c)): del lay[c]
    return lay

FAIL={}
def sees(lay,mk,a,b):
    n=dist(a,b)
    for nudge in (1e-6,-1e-6):
        ok=True
        for i in range(1,n):
            t=i/n; q=a[0]+nudge+(b[0]-a[0])*t; r=a[1]+nudge+(b[1]-a[1])*t; sc=-q-r
            rq,rr,rs=round(q),round(r),round(sc)
            dq,dr,ds=abs(rq-q),abs(rr-r),abs(rs-sc)
            if dq>dr and dq>ds: rq=-rr-rs
            elif dr>ds: rr=-rq-rs
            c=(int(rq),int(rr))
            if c in lay and (lay[c]==WALL or mk.get(c)==OBST): ok=False;break
        if ok: return True
    return False
def regen(path,seed):
    name=os.path.basename(path)[:-5]
    text,lay,mk=load(path)
    rng=random.Random(seed)
    stage=stage_of(name); shop=name.startswith('shop')
    boss=name.startswith('boss'); challenge=name.startswith('challenge')
    n_enemy=sum(1 for m in mk.values() if m==ENEMY)
    # Spare points on normal levels, so the run has safe ones to choose from (dropped if they don't fit)
    spare=2 if name.startswith('normal') else 0
    n_enemy+=spare
    n_loot=sum(1 for m in mk.values() if m==LOOT)
    keep={c:m for c,m in mk.items() if m in (OBST,BOSSPT,SHOP,BANK)}
    arena=boss and '_s' not in name
    if not shop and not arena:
        R=max(RADIUS[stage],min(ecc(c,lay) for c in lay))
        lay=grow(dict(lay),rng,R)
        keep={c:m for c,m in keep.items() if c in lay}
    for attempt in range(200):
        mk=dict(keep)
        # Start: a walkable tile within START_SPREAD of the middle, well in from the edge
        middle=min(lay,key=lambda c:(ecc(c,lay),c))
        outside={n for c in lay for n in nbs(c) if n not in lay}
        inset=lambda c: min(dist(c,o) for o in outside)
        open_=lambda c: lay[c]==N and c not in mk and sum(walkable(lay,mk,o) and o not in mk for o in nbs(c))>=5
        cands=[]
        for gap in (EDGE_GAP,EDGE_GAP-1,1):
            cands=[c for c in lay if dist(c,middle)<=START_SPREAD and open_(c) and inset(c)>=gap]
            if cands: break
        s=rng.choice(sorted(cands)); mk[s]=START
        # Nothing blocking right around the start
        for o in nbs(s):
            if mk.get(o)==OBST: del mk[o]
        reach_r=ecc(s,lay)
        if not shop and not arena:
            # Extra obstacles for cover on bigger boards
            want=max(sum(m==OBST for m in mk.values()), round(len(lay)/24))
            spots=[c for c in sorted(lay) if lay[c]==N and c not in mk and 2<=dist(c,s)<=reach_r-1
                   and not any(mk.get(o)==OBST for o in nbs(c))]
            rng.shuffle(spots)
            for c in spots:
                if sum(m==OBST for m in mk.values())>=want: break
                mk[c]=OBST
                if not connected(lay,mk,s): del mk[c]
        if not connected(lay,mk,s): FAIL["conn"]=FAIL.get("conn",0)+1; continue
        cost=costs_from(lay,mk,s)
        free=lambda c: walkable(lay,mk,c) and c not in mk and c in cost
        enemies=[]
        if n_enemy:
            if boss:
                pool=[c for c in lay if free(c) and dist(c,s)>=reach_r-2]
                for _ in range(n_enemy):
                    pool=[c for c in pool if all(dist(c,e)>=2 for e in enemies)]
                    if not pool: break
                    # First the boss's point (the farthest), then spread out from the others
                    c=max(pool,key=lambda c:(dist(c,s),rng.random())) if not enemies else \
                      max(pool,key=lambda c:(min(adiff(angle(s,c),angle(s,e)) for e in enemies),rng.random()))
                    enemies.append(c)
            else:
                near=[c for c in lay if free(c) and 2<=dist(c,s)<=3 and cost[c]<=3]
                rng.shuffle(near)
                for c in near:
                    if len(enemies)<2 and all(adiff(angle(s,c),angle(s,e))>=math.radians(100) for e in enemies):
                        enemies.append(c)
                far_n=n_enemy-len(enemies)
                rot=rng.random()*2*math.pi
                for k in range(far_n):
                    centre=rot+2*math.pi*k/far_n
                    # Every third point a middle distance; the rest out on the far ring, ideally out of sight of the start
                    lo=4 if k%3==2 else max(4,reach_r-1)
                    pool=[c for c in lay if free(c) and lo<=dist(c,s) and all(dist(c,e)>=2 for e in enemies)
                          and adiff(angle(s,c),centre)<=math.pi/far_n]
                    for near_lo in (4,3):
                        if not pool:
                            pool=[c for c in lay if free(c) and dist(c,s)>=near_lo and all(dist(c,e)>=2 for e in enemies)]
                    if not pool: break
                    enemies.append(max(sorted(pool),key=lambda c:(not sees(lay,mk,c,s))*2+dist(c,s)*0.3+rng.random()))
            if len(enemies)<n_enemy - (spare if attempt>=100 else 0): FAIL["enemy"]=FAIL.get("enemy",0)+1; continue
            for e in enemies: mk[e]=ENEMY
        # Loot: edge tiles well away from the start, tucked in corners or by cover, apart from enemies and each other
        loot=[]
        if n_loot:
            def tucked(c): return sum(o not in lay or lay[o]==WALL or mk.get(o)==OBST for o in nbs(c))
            pool=[c for c in lay if free(c) and lay[c] in (N,D) and tucked(c)>=1 and dist(c,s)*10>=reach_r*6
                  and all(dist(c,e)>=2 for e in enemies)]
            for _ in range(n_loot):
                pool=[c for c in pool if all(dist(c,l)>=4 for l in loot)]
                if not pool: break
                c=max(pool,key=lambda c:(tucked(c)+dist(c,s)*0.5+(min(dist(c,l) for l in loot)*0.3 if loot else 0)+rng.random()))
                loot.append(c)
            if len(loot)<n_loot: FAIL["loot"]=FAIL.get("loot",0)+1; continue
            for l in loot: mk[l]=LOOT
        return lay,mk,s
    raise RuntimeError(name+str(FAIL))

if __name__=='__main__':
    src,out=sys.argv[1],sys.argv[2]
    for p in sorted(glob.glob(src+'/*.tscn')):
        name=os.path.basename(p)[:-5]
        if name.startswith('shop') or (name.startswith('boss_') and '_s' not in name): continue
        text,_,_=load(p)
        lay,mk,s=regen(p,hash(name)%100000 if False else sum(map(ord,name))*7919)
        arr=re.findall(r'tile_map_data = PackedByteArray\("([^"]*)"\)',text)
        text=text.replace(arr[0],encode(lay),1).replace(arr[1],encode(mk),1)
        os.makedirs(out,exist_ok=True); open(os.path.join(out,name+'.tscn'),'w').write(text)
