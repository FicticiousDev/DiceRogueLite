from lvl import *
from PIL import Image, ImageDraw, ImageFont
import math
TC={0:(115,158,90),1:(150,120,80),2:(120,80,105),3:(80,130,190),4:(110,110,120)}
MC={0:(255,255,255),1:(230,50,50),2:(40,40,40),3:(255,220,0),4:(255,170,0),5:(0,200,255),6:(0,120,255),7:(200,90,255)}
def px(c,s):
    # diamond-down axial approx: pointy top. x = s*sqrt3*(q + r/2), y = s*1.5*r ; TILE_LAYOUT_DIAMOND_DOWN -> treat q,r axial
    q,r=c; return (s*math.sqrt(3)*(q+r/2), s*1.5*r)
def draw(lay,mk,title,s=14):
    pts=[px(c,s) for c in lay]; minx=min(p[0] for p in pts)-s*2; miny=min(p[1] for p in pts)-s*2-14
    maxx=max(p[0] for p in pts)+s*2; maxy=max(p[1] for p in pts)+s*2
    im=Image.new('RGB',(int(maxx-minx),int(maxy-miny)),(25,25,30)); d=ImageDraw.Draw(im)
    for c,t in lay.items():
        x,y=px(c,s); x-=minx;y-=miny
        poly=[(x+s*0.95*math.cos(math.radians(60*i+30)), y+s*0.95*math.sin(math.radians(60*i+30))) for i in range(6)]
        d.polygon(poly,fill=TC[t])
        if c in mk:
            m=mk[c]; rr=s*0.45
            if m==2: d.rectangle([x-rr,y-rr,x+rr,y+rr],fill=MC[m])
            else: d.ellipse([x-rr,y-rr,x+rr,y+rr],fill=MC[m])
    d.text((4,2),title,fill=(255,255,255))
    return im
def sheet(ims,cols=4):
    w=max(i.width for i in ims);h=max(i.height for i in ims)
    rows=(len(ims)+cols-1)//cols; out=Image.new('RGB',(w*cols,h*rows),(10,10,12))
    for k,i in enumerate(ims): out.paste(i,((k%cols)*w,(k//cols)*h))
    return out
